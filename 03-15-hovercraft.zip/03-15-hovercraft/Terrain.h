#ifndef TERRAIN_H
#define TERRAIN_H

#include "PlanUtils.h"

typedef struct {
	Point2D pos;
	float rayon;
} Checkpoint;

typedef struct {
 	int nbCheckpoints;
 	Checkpoint Checkpoints[];
} Terrain;
 
Checkpoint init_checkpoint(int centerx, int centery, float rayon);

#endif