#include <stdlib.h>
#include <stdio.h>

#include "PlanUtils.h"

Point2D init_point2D(int x, int y) {
	Point2D p;
	p.x = x;
	p.y = y;
	return p;
}

Vecteur2D init_vecteur2D(int x, int y) {
	Vecteur2D v;
	v.x = x;
	v.y = y;
	return v;
}