#ifndef DRAWFUNCTIONS_H
#define DRAWFUNCTIONS_H

void dessinCarre(int full);
void dessinCercle(int full);
void dessinCarreBordRond(int full);

void dessinHovercraft();
void dessinCheckpoint(int touche);
void dessinPieceFace();
void dessinBoussole();
void dessinFleche();

#endif