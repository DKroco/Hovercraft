#ifndef PLANUTILS_H
#define PLANUTILS_H

typedef struct {
	int x;
	int y;
} Point2D;

typedef Point2D Vecteur2D;

Point2D init_point2D(int x, int y);
Vecteur2D init_vecteur2D(int x, int y);

#endif