#include <stdlib.h>
#include <stdio.h>

#include "Terrain.h"

Checkpoint init_checkpoint(int centerx, int centery, float rayon) {
	Checkpoint cp;
	cp.pos = init_point2D(centerx, centery);
	cp.rayon = rayon;
	return cp;
}