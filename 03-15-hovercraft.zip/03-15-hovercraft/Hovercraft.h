#ifndef HOVERCRAFT_H
#define HOVERCRAFT_H

#include "PlanUtils.h"

typedef struct {
	Point2D pos;
	Vecteur2D vitesse;
	Vecteur2D acceleration;
} Hovercraft;

Hovercraft init_hovercraft(int posx, int posy);

#endif