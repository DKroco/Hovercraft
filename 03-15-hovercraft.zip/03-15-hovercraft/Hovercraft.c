#include <stdlib.h>
#include <stdio.h>

#include "Hovercraft.h"

Hovercraft init_hovercraft(int posx, int posy) {
	Hovercraft hc;
	hc.pos = init_point2D(posx, posy);
	hc.vitesse = init_vecteur2D(0, 0);
	hc.acceleration = init_vecteur2D(0, 0);
	return hc;
}