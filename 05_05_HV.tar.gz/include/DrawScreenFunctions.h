#ifndef DRAWSCREENFUNCTIONS_H
#define DRAWSCREENFUNCTIONS_H

#include "Hovercraft.h"
#include "Playground.h"
#include "ListGeneration.h"

/* Le chronometre */
int timer(Uint32 *currentTime, Uint32 *beforeTime, int *seconds, float *widthTimer, float timerDownInterval);

void drawTexturedScreen(GLuint textureId, Size size);

void rotateCompass(float *arrowAlpha, Playground *playground, Hovercraft *hovercraft);

void drawSoloInterface(Player *player, Playground *playground, Hovercraft *hovercraft, GLuint printlist[], float *arrowAlpha, float widthTimer, float widthTimerReset, float widthSquareReset);

void drawMultiInterface(Player *playerOne, Player *playerTwo, Playground *playground, GLuint printlist[], float *arrowAlphaOne, float *arrowAlphaTwo);

void drawSoloGame(float scale, float *alpha, float rotation, GLuint *printlists, Playground *playground, Hovercraft *hovercraft, GLuint backgroundTexture);

void drawMultiGame(float scale, float *alpha, float rotation, GLuint *printlists, Playground *playground, Hovercraft *hovercraftOne, Hovercraft *hovercraftTwo, GLuint backgroundTexture);

#endif