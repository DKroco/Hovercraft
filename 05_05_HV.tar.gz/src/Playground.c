#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <float.h>
#include <limits.h>
#include <math.h>

#include "Playground.h"

Size initSize(float width, float height) {
  Size s;
  s.width = width;
  s.height = height;
  return s;
}

CheckpointCell * initCheckpointCell(int centerx, int centery, float radius) {
	CheckpointCell *checkpointCell = malloc(sizeof(CheckpointCell));
  if (NULL == checkpointCell) {
    fprintf(stderr, "Erreur mémoire");
    exit(1);
  }
	checkpointCell->pos = initPoint2D(centerx, centery);
	checkpointCell->radius = radius;
  checkpointCell->next = NULL;
	return checkpointCell;
}

Playground * initPlayground() {
  Playground *playground = malloc(sizeof(Playground));
 	if (NULL == playground) {
    fprintf(stderr, "Erreur mémoire");
    exit(1);
  }
 	playground->nbCheckpoints = 0;
  playground->nbCheckpointsRemaining = 0;
 	playground->checkpointList.first = NULL;
  playground->checkpointList.last = NULL;
  playground->halfCoordinatesSize = initSize(0,0);
  playground->timer = 0;
  return playground;
} 

void freeCheckpointCell(CheckpointCell **cell) {
  free(*cell);
  (*cell) = NULL;
}

void freePlayground(Playground **playground) {
  CheckpointCell **cursor = &(*playground)->checkpointList.first;
  CheckpointCell **nextCursor = &(*playground)->checkpointList.first;
  while ((*nextCursor)->next != NULL) {
    *nextCursor = (*cursor)->next;
    free(cursor);
  }
  free(nextCursor);
  free(*playground);
  (*playground) = NULL;
}

void printCheckpointCell(CheckpointCell *checkpointCell) {
  printf("(%f,%f)\n", checkpointCell->pos.x, checkpointCell->pos.y);
}

void printCheckpointList(Playground *playground) {
  CheckpointCell *cursor = playground->checkpointList.first;
  if (cursor == NULL)
    printf("Liste de checkpoints vide !");
  else {
    printf("(");
    while (cursor->next != NULL) {
      printCheckpointCell(cursor);
      printf(",");
      cursor = cursor->next;
    }
    printCheckpointCell(cursor);
    printf(")\n\n");
  }
}

CheckpointCell * convertStringToCheckpoint(char string[]) {
  char strCoordinateX[MAX_SIZE], strCoordinateY[MAX_SIZE], strRadius[MAX_SIZE];
  unsigned int i = 0, j = 0, strLength = strlen(string);

  /* Lecture de la coordonnee X */
  while (string[i] != ',' && i < strLength) {
    strCoordinateX[j++] = string[i++];
  }
  strCoordinateX[j] = '\0';

  /* Lecture de la coordonnee Y */
  i++; /* On passe la virgule */
  if (i < strLength && string[i] != '\n') { /*Le dernier caractère de la chaine peut etre un retour chariot */
    j = 0;
    while (string[i] != ':' && i < strLength) {
      strCoordinateY[j++] = string[i++];
    }
    strCoordinateY[j] = '\0';
  } else
    return NULL;
 
  /* Lecture du rayon */
  i++; /* On passe les deux points */
  if (i < strLength && string[i] != '\n') {
    j = 0;
    while (i < strLength) {
      strRadius[j++] = string[i++];
    }
    strRadius[j] = '\0';
  } else
    return NULL;

  /* Conversion des valeurs */
  float convertedPosX = FLT_MAX, convertedPosY = FLT_MAX, convertedRadius = FLT_MAX;
  sscanf(strCoordinateX, "%f", &convertedPosX);
  sscanf(strCoordinateY, "%f", &convertedPosY);
  sscanf(strRadius, "%f", &convertedRadius);

  /* Vérification des valeurs */
  if (convertedPosX == FLT_MAX || convertedPosY == FLT_MAX || convertedRadius == FLT_MAX) //Si les valeurs n'ont pas été modifiées
    return NULL;
  if (convertedRadius <= 0)
    return NULL;

  /* On retourne le checkpoint créé */
  return initCheckpointCell(convertedPosX, convertedPosY, convertedRadius);
}

Playground * readPlayground(Difficulty levelDifficulty, Size windowSize) {
  Playground *playground = initPlayground();
  CheckpointCell *checkpointCell;
  float minCoordinateX = FLT_MAX, maxCoordinateX = FLT_MIN, minCoordinateY = FLT_MAX, maxCoordinateY = FLT_MIN;
  
  FILE *f;
  switch (levelDifficulty) {
    case NOOB:
      #ifdef OS_Windows /* Le séparateur n'est pas le même sur windows et linux */
        f = fopen("levels\\noob.lvl", "r");
      #else
        f = fopen("levels/noob.lvl", "r");
      #endif 
      playground->timer = 60;  
      break;
    case CAKE:
      #ifdef OS_Windows /* Le séparateur n'est pas le même sur windows et linux */
        f = fopen("levels\\gateau.lvl", "r");
      #else
        f = fopen("levels/gateau.lvl", "r");
      #endif
      playground->timer = 30;
      break;
    case OKLM:
      #ifdef OS_Windows /* Le séparateur n'est pas le même sur windows et linux */
        f = fopen("levels\\oklm.lvl", "r");
      #else
        f = fopen("levels/oklm.lvl", "r");
      #endif
      playground->timer = 20;
      break;
    case PROGAMER:
      #ifdef OS_Windows /* Le séparateur n'est pas le même sur windows et linux */
        f = fopen("levels\\progamer.lvl", "r");
      #else
        f = fopen("levels/progamer.lvl", "r");
      #endif
      playground->timer = 15;
      break;
    case HARDCORE:
      #ifdef OS_Windows /* Le séparateur n'est pas le même sur windows et linux */
        f = fopen("levels\\hardcore.lvl", "r");
      #else
        f = fopen("levels/hardcore.lvl", "r");
      #endif
      playground->timer = 10;
      break;
    case PERSO:
      #ifdef OS_Windows /* Le séparateur n'est pas le même sur windows et linux */
        f = fopen("levels\\perso.lvl", "r");
      #else
        f = fopen("levels/perso.lvl", "r");
      #endif
      playground->timer = 60;
      break;
  }

  FILE *errorfile;

  if (f == NULL) {
    errorfile = fopen("crash_report.txt", "w");
    if (errorfile == NULL) exit(1);
    fprintf(errorfile, "Impossible d'ouvrir le fichier : Vérifiez que le fichier existe dans le dossier 'levels', que vous avez correctement écrit son nom du fichier et que vous possédez les droits en lecture.\n");
    fclose(errorfile);
    exit(1);
  } else {
    unsigned int lineNumber = 0;
    char lineBuffer[MAX_SIZE] = "";

    while (fgets(lineBuffer, MAX_SIZE, f) != NULL) {
      lineNumber++;
      checkpointCell = convertStringToCheckpoint(lineBuffer);

      if (checkpointCell != NULL) {
        addCheckpoint(playground, checkpointCell);

        /* Calcul de la taille de la map */
        if (minCoordinateX > checkpointCell->pos.x - checkpointCell->radius) {
          minCoordinateX = checkpointCell->pos.x - checkpointCell->radius;
        }
        if (maxCoordinateX < checkpointCell->pos.x + checkpointCell->radius) {
          maxCoordinateX = checkpointCell->pos.x + checkpointCell->radius;
        }
        if (minCoordinateY > checkpointCell->pos.y - checkpointCell->radius) {
          minCoordinateY = checkpointCell->pos.y - checkpointCell->radius;
        }
        if (maxCoordinateY < checkpointCell->pos.y + checkpointCell->radius) {
          maxCoordinateY = checkpointCell->pos.y + checkpointCell->radius;
        }
      } else { /* Si checkpoint est null, on quitte le jeu */
        fclose(f);
        errorfile = fopen("crash_report.txt", "w");
        if (errorfile == NULL) exit(1);
        fprintf(errorfile, "Fichier - Erreur ligne %d : Format de checkpoint incorrect\nFormat : x,y:r avec x,y coordonnées de l'origine et r rayon du checkpoint", lineNumber);
        fclose(errorfile);
        exit(1);
      }

    }

    /* Il est inutile de lancer le jeu s'il n'y a pas de checkpoint */
    if (playground->nbCheckpoints < 1) {
      fclose(f);
      errorfile = fopen("crash_report.txt", "w");
      if (errorfile == NULL) exit(1);
      fprintf(errorfile, "Fichier - Le terrain doit contenir plus de checkpoints\nFormat d'écriture d'un checkpoint : x,y:r avec x,y coordonnées de l'origine et r rayon du checkpoint");
      fclose(errorfile);
      exit(1);
    }

    fclose(f);
  }

  /* Calcul des intervalles nécessaires pour que tous les checkpoints soient dans le terrain */
  if (maxCoordinateX <= maxCoordinateY || abs(minCoordinateX) <= abs(minCoordinateY)) { /*Si le terrain est plus haut que large, 
  on souhaite tout de même le faire rentrer dans une fenêtre plus large que haute */
    if (maxCoordinateY > fabs(minCoordinateY)) {
      playground->halfCoordinatesSize.height = maxCoordinateY;
      playground->halfCoordinatesSize.width = maxCoordinateY*windowSize.width/windowSize.height;
    } else {
      playground->halfCoordinatesSize.height = fabs(minCoordinateY); /* Valeur absolue d'un float */
      playground->halfCoordinatesSize.width = fabs(minCoordinateY)*windowSize.width/windowSize.height;
    }
  } else {
    if (maxCoordinateX > fabs(minCoordinateX)) {
      playground->halfCoordinatesSize.width = maxCoordinateX;
      playground->halfCoordinatesSize.height = maxCoordinateX*windowSize.height/windowSize.width;
    } else {
      playground->halfCoordinatesSize.width = fabs(minCoordinateX);
      playground->halfCoordinatesSize.height = fabs(minCoordinateX)*windowSize.height/windowSize.width;
    }
  }
  
  return playground;
}

void addCheckpoint(Playground *playground, CheckpointCell *checkpointCell) {
  if (playground->checkpointList.last == NULL) {  /* Si le dernier est à null, alors le premier aussi, on "initialise" la file */
    playground->checkpointList.first = checkpointCell;
  } else {
    playground->checkpointList.last->next = checkpointCell;
  }
  playground->checkpointList.last = checkpointCell;
  playground->nbCheckpoints += 1;
  playground->nbCheckpointsRemaining += 1;
}

void deleteCheckpoint(Playground *playground) {
  /* TODO il manque quelque chose là : cas ou first->next == null, ou first == last */
  if (playground->checkpointList.first != NULL) {
    playground->checkpointList.first = playground->checkpointList.first->next;
    playground->nbCheckpointsRemaining -= 1;
  } else {
    fprintf(stderr, "Liste vide");
  }
}

CheckpointCell * getFirstCheckpoint(Playground *playground) {
  return playground->checkpointList.first;
}