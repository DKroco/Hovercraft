#include <SDL/SDL.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <SDL/SDL_image.h>

#include "Events.h"

void sound(Mix_Chunk *soundClic, Mix_Chunk *soundHover, int testSound, int *alreadyPlayed){
	if(testSound == 1 && *alreadyPlayed == 0)
		Mix_PlayChannel(-1,soundClic,0);
	else if(testSound == 2 && *alreadyPlayed == 0){
		Mix_PlayChannel(-1,soundHover,0);
	}
}

void handleMenuEvent(GameState *gameState, int *loop, int *breakingMenuLoop, int *multiplayers,Mix_Chunk *soundClic, Mix_Chunk *soundHover, int *alreadyPlayed) {
	SDL_Event e;
	int alreadyPlayedClic = 0;
	while(SDL_PollEvent(&e)) {
		if(e.type == SDL_QUIT) {
			*loop = 0;
			break;
		}

		float xcoord, ycoord;
		switch(e.type) {
			case SDL_MOUSEBUTTONDOWN:
				/* On récupére la position du clic */
				xcoord = e.button.x;
				ycoord = e.button.y;
				if (xcoord > 600 && xcoord < 1250 && ycoord > 55 && ycoord < 165) { /* Clic sur le bouton de jeu solo */
					sound(soundClic,soundHover,1,&alreadyPlayedClic);
					*gameState = LEVEL_SELECTION;
					*multiplayers = 0;
					*breakingMenuLoop = 1;
				} else if (xcoord > 600 && xcoord < 1250 && ycoord > 210 && ycoord < 320) { /* Clic sur le bouton de jeu multi */
					sound(soundClic,soundHover,1,&alreadyPlayedClic);
					*gameState = LEVEL_SELECTION;
					*multiplayers = 1;
					*breakingMenuLoop = 1;
				} else if (xcoord > 600 && xcoord < 1250 && ycoord > 365 && ycoord < 470) {
					sound(soundClic,soundHover,1,&alreadyPlayedClic);
					*gameState = TUTORIAL;
				} else if (xcoord > 600 && xcoord < 1250 && ycoord > 520 && ycoord < 630) { /* Clic sur le bouton quitter */
					sound(soundClic,soundHover,1,&alreadyPlayedClic);
					*loop = 0;
					
				}
				break;
			/* Survol des cases */
			case SDL_MOUSEMOTION:
				xcoord = e.button.x;
				ycoord = e.button.y;
				if (xcoord > 600 && xcoord < 1250 && ycoord > 55 && ycoord < 165) { 
					if(!(*alreadyPlayed)){
						sound(soundClic,soundHover,2,alreadyPlayed);
						*alreadyPlayed = 1;
					}
				} else if (xcoord > 600 && xcoord < 1250 && ycoord > 210 && ycoord < 320) { 
					if(!(*alreadyPlayed)){
						sound(soundClic,soundHover,2,alreadyPlayed);
						*alreadyPlayed = 1;
					}
				} else if (xcoord > 600 && xcoord < 1250 && ycoord > 365 && ycoord < 470) {
					if(!(*alreadyPlayed)){
						sound(soundClic,soundHover,2,alreadyPlayed);
						*alreadyPlayed = 1;
					}
				} else if (xcoord > 600 && xcoord < 1250 && ycoord > 520 && ycoord < 630) { 
					if(!(*alreadyPlayed)){
						sound(soundClic,soundHover,2,alreadyPlayed);
						*alreadyPlayed = 1;
					}
				}else{
					*alreadyPlayed = 0;
				}
				break;

			/* Touche clavier */
			case SDL_KEYDOWN:
				switch (e.key.keysym.sym) {
				case SDLK_ESCAPE:
			       	*loop = 0;
			       	break;
			    default:
			       	break;
				}
				break;

			default:
			  	break;
		}
	}
}

void handleTutorialEvent(GameState *gameState, int *loop,Mix_Chunk *soundClic, Mix_Chunk *soundHover, int *alreadyPlayed) {
	SDL_Event e;
	int alreadyPlayedClic = 0;
	while(SDL_PollEvent(&e)) {
		if(e.type == SDL_QUIT) {
			*loop = 0;
			break;
		}

		float xcoord, ycoord;
		switch(e.type) {
		case SDL_MOUSEBUTTONDOWN:
			/* On récupére la position du clic */
			xcoord = e.button.x;
			ycoord = e.button.y;

			if (xcoord > 1110 && xcoord < 1240 && ycoord > 50 && ycoord < 155) { /* Clic sur le bouton de jeu solo */
				sound(soundClic,soundHover,1,&alreadyPlayedClic);
				*gameState = MENU;
			}
		
			break;

		case SDL_MOUSEMOTION:
			/* On récupére la position du clic */
			xcoord = e.button.x;
			ycoord = e.button.y;

			if (xcoord > 1110 && xcoord < 1240 && ycoord > 50 && ycoord < 155) { /* Clic sur le bouton de jeu solo */
				if(!(*alreadyPlayed)){
					sound(soundClic,soundHover,2,alreadyPlayed);
					*alreadyPlayed = 1;
				}
			}
		
			break;

		/* Touche clavier */
		case SDL_KEYDOWN:
			switch (e.key.keysym.sym) {
			case SDLK_ESCAPE:
		       	*loop = 0;
		       	break;
		    default:
		       	break;
			}
			break;

		default:
		  	break;
		}
	}
}

void handleLevelSelectionEvent(GameState *gameState, int *loop, int *breakingMenuLoop, int multiplayers, Difficulty *levelDifficulty, int *seconds, int secondsReset, float *widthTimer, float widthTimerReset, Mix_Chunk *soundClic, Mix_Chunk *soundHover, int *alreadyPlayed) {
	SDL_Event e;
	int alreadyPlayedClic = 0;
	*seconds = secondsReset;
	*widthTimer = widthTimerReset;
	while(SDL_PollEvent(&e)) {
		if(e.type == SDL_QUIT) {
			*loop = 0;
			break;
		}

		float xcoord, ycoord;
		switch(e.type) {
		case SDL_MOUSEBUTTONDOWN:
			/* On récupére la position du clic */
			xcoord = e.button.x;
			ycoord = e.button.y;
			int launchGame = 0;

			if (xcoord > 1110 && xcoord < 1240 && ycoord > 50 && ycoord < 155) { /* Clic sur le bouton de jeu solo */
				sound(soundClic,soundHover,1,&alreadyPlayedClic);
				*alreadyPlayed = 1;
				*gameState = MENU;
			} else if (xcoord > 40 && xcoord < 620 && ycoord > 245 && ycoord < 355) {
				sound(soundClic,soundHover,1,&alreadyPlayedClic);
				*alreadyPlayed = 1;
				*levelDifficulty = NOOB;
				launchGame = 1;
			} else if (xcoord > 40 && xcoord < 620 && ycoord > 400 && ycoord < 510) {
				sound(soundClic,soundHover,1,&alreadyPlayedClic);
				*alreadyPlayed = 1;
				*levelDifficulty = CAKE;
				launchGame = 1;
			} else if (xcoord > 40 && xcoord < 620 && ycoord > 555 && ycoord < 665) {
				sound(soundClic,soundHover,1,&alreadyPlayedClic);
				*alreadyPlayed = 1;
				*levelDifficulty = OKLM;
				launchGame = 1;
			} else if (xcoord > 660 && xcoord < 1240 && ycoord > 245 && ycoord < 355) {
				sound(soundClic,soundHover,1,&alreadyPlayedClic);
				*alreadyPlayed = 1;
				*levelDifficulty = PROGAMER;
				launchGame = 1;
			} else if (xcoord > 660 && xcoord < 1240 && ycoord > 400 && ycoord < 510) {
				sound(soundClic,soundHover,1,&alreadyPlayedClic);
				*alreadyPlayed = 1;
				*levelDifficulty = HARDCORE;
				launchGame = 1;
			} else if (xcoord > 660 && xcoord < 1240 && ycoord > 555 && ycoord < 665) {
				sound(soundClic,soundHover,1,&alreadyPlayedClic);
				*alreadyPlayed = 1;
				*levelDifficulty = PERSO;
				launchGame = 1;
			}
			if (launchGame) {
				if (multiplayers)
					*gameState = MULTI_GAME;
				else
					*gameState = SOLO_GAME;
			}


		
			break;

			case SDL_MOUSEMOTION:
			/* On récupére la position du clic */
			xcoord = e.button.x;
			ycoord = e.button.y;

			if (xcoord > 1110 && xcoord < 1240 && ycoord > 50 && ycoord < 155) { /* Clic sur le bouton de jeu solo */
				if(!(*alreadyPlayed)){
					sound(soundClic,soundHover,2,alreadyPlayed);
					*alreadyPlayed = 1;
				}
			} else if (xcoord > 40 && xcoord < 620 && ycoord > 245 && ycoord < 355) {
				if(!(*alreadyPlayed)){
					sound(soundClic,soundHover,2,alreadyPlayed);
					*alreadyPlayed = 1;
				}
			} else if (xcoord > 40 && xcoord < 620 && ycoord > 400 && ycoord < 510) {
				if(!(*alreadyPlayed)){
					sound(soundClic,soundHover,2,alreadyPlayed);
					*alreadyPlayed = 1;
				}
			} else if (xcoord > 40 && xcoord < 620 && ycoord > 555 && ycoord < 665) {
				if(!(*alreadyPlayed)){
					sound(soundClic,soundHover,2,alreadyPlayed);
					*alreadyPlayed = 1;
				}
			} else if (xcoord > 660 && xcoord < 1240 && ycoord > 245 && ycoord < 355) {
				if(!(*alreadyPlayed)){
					sound(soundClic,soundHover,2,alreadyPlayed);
					*alreadyPlayed = 1;
				}
			} else if (xcoord > 660 && xcoord < 1240 && ycoord > 400 && ycoord < 510) {
				if(!(*alreadyPlayed)){
					sound(soundClic,soundHover,2,alreadyPlayed);
					*alreadyPlayed = 1;
				}
			} else if (xcoord > 660 && xcoord < 1240 && ycoord > 555 && ycoord < 665) {
				if(!(*alreadyPlayed)){
					sound(soundClic,soundHover,2,alreadyPlayed);
					*alreadyPlayed = 1;
				}
			}else{
				*alreadyPlayed = 0;
			}
		
			break;

		/* Touche clavier */
		case SDL_KEYDOWN:
			switch (e.key.keysym.sym) {
			case SDLK_ESCAPE:
		       	*loop = 0;
		       	break;
		    default:
		       	break;
			}
			break;

		default:
		  	break;
		}
	}
}

void handleEndOfGameEvent(GameState *gameState, int *loop, int *breakingMenuLoop, int multiplayers, int *seconds, int secondsReset, float *widthTimer, float widthTimerReset, Mix_Chunk *soundClic, Mix_Chunk *soundHover, int *alreadyPlayed) {
	SDL_Event e;
	int alreadyPlayedClic = 0;
	*seconds = secondsReset;
	*widthTimer = widthTimerReset;
	while(SDL_PollEvent(&e)) {
		if(e.type == SDL_QUIT) {
			*loop = 0;
			break;
		}

		float xcoord, ycoord;
		switch(e.type) {
		case SDL_MOUSEBUTTONDOWN:
			/* On récupére la position du clic */
			xcoord = e.button.x;
			ycoord = e.button.y;

			if (xcoord > 320 && xcoord < 970 && ycoord > 245 && ycoord < 355) { /* Clic sur le bouton de jeu solo */
				sound(soundClic,soundHover,1,&alreadyPlayedClic);
				if (multiplayers)
					*gameState = MULTI_GAME;
				else
					*gameState = SOLO_GAME;
				*breakingMenuLoop = 1;
			} else if (xcoord > 320 && xcoord < 970 && ycoord > 400 && ycoord < 510) {
				sound(soundClic,soundHover,1,&alreadyPlayedClic);
				*gameState = MENU;
			} else if (xcoord > 320 && xcoord < 970 && ycoord > 555 && ycoord < 665) {
				sound(soundClic,soundHover,1,&alreadyPlayedClic);
				*loop = 0;
			}
		
			break;

		case SDL_MOUSEMOTION:
			/* On récupére la position du clic */
			xcoord = e.button.x;
			ycoord = e.button.y;

			if (xcoord > 320 && xcoord < 970 && ycoord > 245 && ycoord < 355) { /* Clic sur le bouton de jeu solo */
				if(!(*alreadyPlayed)){
					sound(soundClic,soundHover,2,alreadyPlayed);
					*alreadyPlayed = 1;
				}
			} else if (xcoord > 320 && xcoord < 970 && ycoord > 400 && ycoord < 510) {
				if(!(*alreadyPlayed)){
					sound(soundClic,soundHover,2,alreadyPlayed);
					*alreadyPlayed = 1;
				}
			} else if (xcoord > 320 && xcoord < 970 && ycoord > 555 && ycoord < 665) {
				if(!(*alreadyPlayed)){
					sound(soundClic,soundHover,2,alreadyPlayed);
					*alreadyPlayed = 1;
				}
			}else{
				*alreadyPlayed = 0;
			}
		
			break;

		/* Touche clavier */
		case SDL_KEYDOWN:
			switch (e.key.keysym.sym) {
			case SDLK_ESCAPE:
		       	*loop = 0;
		       	break;
		    default:
		       	break;
			}
			break;

		default:
		  	break;
		}
	}
}

void handlePauseEvent(GameState *gameState, int *loop, int *breakingMenuLoop, int multiplayers, Mix_Chunk *soundClic, Mix_Chunk *soundHover, int *alreadyPlayed) {
	SDL_Event e;
	int alreadyPlayedClic = 0;
	while(SDL_PollEvent(&e)) {
		if(e.type == SDL_QUIT) {
			*loop = 0;
			break;
		}

		float xcoord, ycoord;
		switch(e.type) {
		case SDL_MOUSEBUTTONDOWN:
			/* On récupére la position du clic */
			xcoord = e.button.x;
			ycoord = e.button.y;

			if (xcoord > 1110 && xcoord < 1240 && ycoord > 55 && ycoord < 165) { 
				sound(soundClic,soundHover,1,&alreadyPlayedClic);
				if (multiplayers)
					*gameState = MULTI_GAME;
				else
					*gameState = SOLO_GAME;
			} else if (xcoord > 320 && xcoord < 970 && ycoord > 300 && ycoord < 405) {
				sound(soundClic,soundHover,1,&alreadyPlayedClic);
				if (multiplayers)
					*gameState = MULTI_GAME;
				else
					*gameState = SOLO_GAME;
				*breakingMenuLoop = 1;
			} else if (xcoord > 320 && xcoord < 970 && ycoord > 490 && ycoord < 600) {
				sound(soundClic,soundHover,1,&alreadyPlayedClic);
				*gameState = MENU;
			}
		
			break;

		case SDL_MOUSEMOTION:
			/* On récupére la position du clic */
			xcoord = e.button.x;
			ycoord = e.button.y;

			if (xcoord > 1110 && xcoord < 1240 && ycoord > 55 && ycoord < 165) {
				if(!(*alreadyPlayed)){
					sound(soundClic,soundHover,2,alreadyPlayed);
					*alreadyPlayed = 1;
				}
			} else if (xcoord > 320 && xcoord < 970 && ycoord > 300 && ycoord < 405) {
				if(!(*alreadyPlayed)){
					sound(soundClic,soundHover,2,alreadyPlayed);
					*alreadyPlayed = 1;
				}
			} else if (xcoord > 320 && xcoord < 970 && ycoord > 490 && ycoord < 600) {
				if(!(*alreadyPlayed)){
					sound(soundClic,soundHover,2,alreadyPlayed);
					*alreadyPlayed = 1;
				}
			}else{
				*alreadyPlayed = 0;
			}
		
			break;

		/* Touche clavier */
		case SDL_KEYDOWN:
			switch (e.key.keysym.sym) {
			case SDLK_ESCAPE:
		       	*loop = 0;
		       	break;
		    case SDLK_p:
		    	if (multiplayers)
					*gameState = MULTI_GAME;
				else
					*gameState = SOLO_GAME;
		    	break;
		    default:
		       	break;
			}
			break;

		default:
		  	break;
		}
	}
}

void handleEasterEggEvent(GameState *gameState, int *loop, int *breakingMenuLoop, int multiplayers, Mix_Chunk *soundClic, Mix_Chunk *soundHover, int *alreadyPlayed) {
	SDL_Event e;
	int alreadyPlayedClic = 0;
	while(SDL_PollEvent(&e)) {
		if(e.type == SDL_QUIT) {
			*loop = 0;
			break;
		}

		float xcoord, ycoord;
		switch(e.type) {
		case SDL_MOUSEBUTTONDOWN:
			/* On récupére la position du clic */
			xcoord = e.button.x;
			ycoord = e.button.y;

			if (xcoord > 1110 && xcoord < 1240 && ycoord > 55 && ycoord < 165) {
				sound(soundClic,soundHover,1,&alreadyPlayedClic);
				if (multiplayers)
					*gameState = MULTI_GAME;
				else
					*gameState = SOLO_GAME;
			} else if (xcoord > 320 && xcoord < 970 && ycoord > 300 && ycoord < 405) {
				sound(soundClic,soundHover,1,&alreadyPlayedClic);
				if (multiplayers)
					*gameState = MULTI_GAME;
				else
					*gameState = SOLO_GAME;
				*breakingMenuLoop = 1;
			} else if (xcoord > 320 && xcoord < 970 && ycoord > 490 && ycoord < 600) {
				sound(soundClic,soundHover,1,&alreadyPlayedClic);
				*gameState = MENU;
			}
		
			break;

		case SDL_MOUSEMOTION:
			/* On récupére la position du clic */
			xcoord = e.button.x;
			ycoord = e.button.y;

			if (xcoord > 1110 && xcoord < 1240 && ycoord > 55 && ycoord < 165) {
				if(!(*alreadyPlayed)){
					sound(soundClic,soundHover,2,alreadyPlayed);
					*alreadyPlayed = 1;
				}
			} else if (xcoord > 320 && xcoord < 970 && ycoord > 300 && ycoord < 405) {
				if(!(*alreadyPlayed)){
					sound(soundClic,soundHover,2,alreadyPlayed);
					*alreadyPlayed = 1;
				}
			} else if (xcoord > 320 && xcoord < 970 && ycoord > 490 && ycoord < 600) {
				if(!(*alreadyPlayed)){
					sound(soundClic,soundHover,2,alreadyPlayed);
					*alreadyPlayed = 1;
				}
			}else{
				*alreadyPlayed = 0;
			}
		
			break;

		/* Touche clavier */
		case SDL_KEYDOWN:
			switch (e.key.keysym.sym) {
			case SDLK_ESCAPE:
		       	*loop = 0;
		       	break;
		    case SDLK_v:
		    	if (multiplayers)
					*gameState = MULTI_GAME;
				else
					*gameState = SOLO_GAME;
		    	break;
		    default:
		       	break;
			}
			break;

		default:
		  	break;
		}
	}
}


void handleSoloGameEvent(GameState *gameState, int *loop, float *scale, Player *player) {
	SDL_Event e;
	while(SDL_PollEvent(&e)) {
		if(e.type == SDL_QUIT) {
			*loop = 0;
			break;
		}

		switch(e.type) {
		case SDL_MOUSEBUTTONDOWN:
			
			break;

		/* Touche clavier */
		case SDL_KEYDOWN:
			/* On est obligé d'utiliser un if car les case ne prennent que des constantes définies à la compilation ... */
			if (e.key.keysym.sym == SDLK_ESCAPE) { 
		       	*loop = 0;
		    } else if (e.key.keysym.sym == player->controller->left) {
		       	player->keyPressed->leftPressed = 1;
		    } else if (e.key.keysym.sym == player->controller->right) {
		       	player->keyPressed->rightPressed = 1;
		    } else if (e.key.keysym.sym == player->controller->up) {
		       	player->keyPressed->upPressed = 1;
		    } else if (e.key.keysym.sym == SDLK_p) {
		    	*gameState = PAUSE;
		    } else if (e.key.keysym.sym == SDLK_v) {
		    	*gameState = EASTER_EGG;
		    }
		    break;

		case SDL_KEYUP:
			if (e.key.keysym.sym == player->controller->left) {
		       	player->keyPressed->leftPressed = 0;
		    } else if (e.key.keysym.sym == player->controller->right) {
		       	player->keyPressed->rightPressed = 0;
		    } else if (e.key.keysym.sym == player->controller->up) {
		       	player->keyPressed->upPressed = 0;
		    } else if (e.key.keysym.sym == SDLK_i) {
		    	*scale += 0.5;
		    } else if (e.key.keysym.sym == SDLK_o) {
		    	if (*scale != 1.)
		    		*scale -= 0.5;
		    }
    		break;

		default:
		  	break;
		}
	}
}

void handleMultiGameEvent(GameState *gameState, int *loop, float *scale, Player *playerOne, Player *playerTwo) {
	SDL_Event e;
	while(SDL_PollEvent(&e)) {
		if(e.type == SDL_QUIT) {
			*loop = 0;
			break;
		}

		switch(e.type) {
		case SDL_MOUSEBUTTONDOWN:
			break;

		/* Touche clavier */
		case SDL_KEYDOWN:
			/* On est obligé d'utiliser un if car les case ne prennent que des constantes définies à la compilation ... */
			if (e.key.keysym.sym == SDLK_ESCAPE) { 
		       	*loop = 0;
		    } else if (e.key.keysym.sym == playerOne->controller->left) {
		       	playerOne->keyPressed->leftPressed = 1;
		    } else if (e.key.keysym.sym == playerOne->controller->right) {
		       	playerOne->keyPressed->rightPressed = 1;
		    } else if (e.key.keysym.sym == playerOne->controller->up) {
		       	playerOne->keyPressed->upPressed = 1;
		    } else if (e.key.keysym.sym == playerTwo->controller->left) {
		       	playerTwo->keyPressed->leftPressed = 1;
		    } else if (e.key.keysym.sym == playerTwo->controller->right) {
		       	playerTwo->keyPressed->rightPressed = 1;
		    } else if (e.key.keysym.sym == playerTwo->controller->up) {
		       	playerTwo->keyPressed->upPressed = 1;
		    } else if (e.key.keysym.sym == SDLK_p) {
		    	*gameState = PAUSE;
		    } else if (e.key.keysym.sym == SDLK_v) {
		    	*gameState = EASTER_EGG;
		    }
		    break;

		case SDL_KEYUP:
			if (e.key.keysym.sym == playerOne->controller->left) {
		       	playerOne->keyPressed->leftPressed = 0;
		    } else if (e.key.keysym.sym == playerOne->controller->right) {
		       	playerOne->keyPressed->rightPressed = 0;
		    } else if (e.key.keysym.sym == playerOne->controller->up) {
		       	playerOne->keyPressed->upPressed = 0;
		    } else if (e.key.keysym.sym == playerTwo->controller->left) {
		       	playerTwo->keyPressed->leftPressed = 0;
		    } else if (e.key.keysym.sym == playerTwo->controller->right) {
		       	playerTwo->keyPressed->rightPressed = 0;
		    } else if (e.key.keysym.sym == playerTwo->controller->up) {
		       	playerTwo->keyPressed->upPressed = 0;
		    }
		    /* Pas de possibilité de zoomer en mode multi (nécessité de spliter l'écran sinon...) */
    		break;

		default:
		  	break;
		}
	}
}

int checkSoloWin(Player *player, Hovercraft *hovercraft, Playground *playground, GameState *gameState, Mix_Chunk *soundCheckpoint, Mix_Chunk *soundWin) {
  if (checkCheckpointCollision(hovercraft, getFirstCheckpoint(playground)) != NO_COLLISION) {
  	/* S'il y a collision, on supprime le checkpoint, et on augmente le compteur */
    deleteCheckpoint(playground);
    (player->score)++;
	if(0 == playground->nbCheckpointsRemaining) {
		Mix_PlayChannel(-1,soundWin,0);
		*gameState = SOLO_WIN;
		return 1;
    }else{
    	Mix_PlayChannel(-1,soundCheckpoint,0);
    }
  }
  return 0;
}

int checkMultiWin(Player *playerOne, Player *playerTwo, Playground *playground, GameState *gameState, Mix_Chunk *soundCheckpoint, Mix_Chunk *soundWin, Mix_Chunk *soundGameOver) {
	if(checkCheckpointCollision(playerOne->hovercraft, getFirstCheckpoint(playground)) != NO_COLLISION) {
		deleteCheckpoint(playground);
		(playerOne->score)++;
		if(playground->nbCheckpointsRemaining == 0 && (playerOne->score == playerTwo->score)){
			Mix_PlayChannel(-1,soundGameOver,0);
			*gameState = EQUAL;
			return 1;
		}else if(playerOne->score > (playground->nbCheckpoints)/2) {
			Mix_PlayChannel(-1,soundWin,0);
			*gameState = MULTI_WIN_P1;
			return 1;
		}else{
	    	Mix_PlayChannel(-1,soundCheckpoint,0);
	    }
	}else if(checkCheckpointCollision(playerTwo->hovercraft, getFirstCheckpoint(playground)) != NO_COLLISION) {
		deleteCheckpoint(playground);
		(playerTwo->score)++;
		if(playground->nbCheckpointsRemaining == 0 && (playerOne->score == playerTwo->score)){
			Mix_PlayChannel(-1,soundGameOver,0);
			*gameState = EQUAL;
			return 1;
		}else if(playerTwo->score > (playground->nbCheckpoints)/2) {
			Mix_PlayChannel(-1,soundWin,0);
			*gameState = MULTI_WIN_P2;
			return 1;
		}else{
	    	Mix_PlayChannel(-1,soundCheckpoint,0);
	    }
	}
	
    return 0;
}