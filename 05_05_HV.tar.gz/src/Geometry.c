#include <stdlib.h>
#include <stdio.h>

#include "Geometry.h"

Point2D initPoint2D(float x, float y) {
	Point2D p;
	p.x = x;
	p.y = y;
	return p;
}

Vector2D initVector2D(float x, float y) {
	Vector2D v;
	v.x = x;
	v.y = y;
	return v;
}

Vector2D updateVector2D(float x, float y) {
	Vector2D v;
	v.x = x;
	v.y = y;
	return v;
}

Vector2D addVectors(Vector2D u, Vector2D v) {
    return initVector2D(u.x + v.x, u.y + v.y);
}

Vector2D subVectors(Vector2D u, Vector2D v) {
    return initVector2D(u.x - v.x, u.y - v.y);
}

Vector2D multVector(Vector2D u, float a) {
    return initVector2D(u.x * a, u.y * a);
}

Vector2D divVector(Vector2D u, float a) {
    return initVector2D(u.x / a, u.y / a);
}

float dotProduct(Vector2D u, Vector2D v) {
    return u.x * v.x + u.y * v.y;
}

float sqrNorm(Vector2D v) {
    return dotProduct(v, v);
}

float norm(Vector2D v) {
    return sqrt(sqrNorm(v));
}

Vector2D normalize(Vector2D v) {
    return divVector(v, norm(v));
}

/* Fonction pour arrondir à l'entier le plus proche */
int roundValue(float value) {
     return floor(value + 0.5);
}

/* Fonction de conversion de degré en radians */
float degToRad(float angleDegre) {
	return angleDegre*PI/180;
}

/* Fonction de conversion de radians en degres */
float radToDeg(float angleRadian) {
	return 180*angleRadian/PI;
}