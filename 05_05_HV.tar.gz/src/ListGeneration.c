#include <SDL/SDL.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <stdlib.h>
#include <stdio.h>
#include <ListGeneration.h>

/* Permet la création de toutes les listes d'affichages utilisées */
GLuint * generatePrintLists() {
	GLuint *printlists = malloc(sizeof(GLuint)*NB_PRINTLISTS);

	printlists[ID_HOVERCRAFT] = glGenLists(1);
	glNewList(printlists[ID_HOVERCRAFT], GL_COMPILE);
		drawHovercraft(0);   
	glEndList();

	printlists[ID_HOVERCRAFT_J2] = glGenLists(1);
	glNewList(printlists[ID_HOVERCRAFT_J2], GL_COMPILE);
		drawHovercraft(1);   
	glEndList();

	printlists[ID_CHECKPOINT] = glGenLists(1);
	glNewList(printlists[ID_CHECKPOINT], GL_COMPILE);
		drawCheckpoint(0,0);   
	glEndList();

	printlists[ID_PIECE] = glGenLists(1);
	glNewList(printlists[ID_PIECE], GL_COMPILE);
		drawCheckpoint(1,0);   
	glEndList();

	printlists[ID_PIECE_TOUCHE] = glGenLists(1);
	glNewList(printlists[ID_PIECE_TOUCHE], GL_COMPILE);
		drawCheckpoint(0,0);   
	glEndList();

	printlists[ID_PIECE_J2_TOUCHE] = glGenLists(1);
	glNewList(printlists[ID_PIECE_J2_TOUCHE], GL_COMPILE);
		drawCheckpoint(0,1);   
	glEndList();

	return printlists;
}

void freePrintlists(GLuint **printlists) {
	free(*printlists);
	(*printlists) = NULL;
}

GLenum getImgFormat(SDL_Surface *image) {
	GLenum format;
	FILE *errorfile;
    switch(image->format->BytesPerPixel) {
        case 1:
            format = GL_RED;
            break;
        case 3:
            format = GL_RGB;
            break;
        case 4:
            format = GL_RGBA;
            break;
        default:	
        	fprintf(stderr, "Format des pixels de l'image non pris en charge\n");
			errorfile = fopen("crash_report.txt", "w");
			if (errorfile == NULL) exit(1);
			fprintf(errorfile, "Format des pixels de l'image non pris en charge\n");
			fclose(errorfile);
			exit(EXIT_FAILURE);
    }

    return format;
}

/* Ouverture de l'image imgPath */
SDL_Surface * loadImage(char imgPath[]) {
	SDL_Surface *image = IMG_Load(imgPath);
    if(image == NULL) {
    	FILE *errorfile;
        fprintf(stderr, "Impossible de charger l'image");
        errorfile = fopen("crash_report.txt", "w");
		if (errorfile == NULL) exit(1);
		fprintf(errorfile, "Texture - l'image ne s'est pas chargé (fonction loadImage) \n");
		fclose(errorfile);
        exit(EXIT_FAILURE);
    }

    return image;
}

/* Permet de créer la texture engendrée par imgPath */
GLuint createTexture(char imgPath[]) {
	GLuint textureId;
	
    glGenTextures(1, &textureId);
    glBindTexture(GL_TEXTURE_2D, textureId);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

    SDL_Surface *image = loadImage(imgPath);
    GLenum format = getImgFormat(image);
	

    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, image->w, image->h, 0, format, GL_UNSIGNED_BYTE, image->pixels);
    glBindTexture(GL_TEXTURE_2D, 0);
    
    SDL_FreeSurface(image);

    return textureId;
}

/* Permet la création de toutes les textures utilisées */
GLuint * generateTextures() {
	char * texturesPath[] = {"img/background.jpg", "img/menu.png", "img/pause.png", "img/easterEgg.png", "img/tuto.png", "img/levelSelection.png", "img/winSolo.png", "img/winMultiP1.png", "img/winMultiP2.png", "img/egalite.png", "img/gameOver.png"};
	GLuint *textures = malloc(sizeof(GLuint)*NB_TEXTURES);

	int i;
	for (i = 0; i < NB_TEXTURES; i++) {
		textures[i] = createTexture(texturesPath[i]);
	}

	return textures;
}

void freeTextures(GLuint **textures) {
	free(*textures);
	(*textures) = NULL;
}