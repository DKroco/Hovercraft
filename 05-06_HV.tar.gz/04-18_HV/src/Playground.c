#include "Playground.h"

Size initSize(float width, float height) {
  Size s;
  s.width = width;
  s.height = height;
  return s;
}

CheckpointCell * initCheckpointCell(int centerx, int centery, float radius) {
	CheckpointCell *checkpointCell = malloc(sizeof(CheckpointCell));
  if (NULL == checkpointCell) {
    fprintf(stderr, "Erreur mémoire");
    exit(1);
  }
	checkpointCell->pos = initPoint2D(centerx, centery);
	checkpointCell->radius = radius;
  checkpointCell->next = NULL;
	return checkpointCell;
}

Playground * initPlayground() {
  Playground *playground = malloc(sizeof(Playground));
 	if (NULL == playground) {
    fprintf(stderr, "Erreur mémoire");
    exit(1);
  }
 	playground->nbCheckpoints = 0;
  playground->nbCheckpointsRemaining = 0;
 	playground->checkpointList.first = NULL;
  playground->checkpointList.last = NULL;
  playground->halfCoordinatesSize = initSize(0,0);
  playground->timer = 0;
  return playground;
} 

void freeCheckpointCell(CheckpointCell **cell) {
  free(*cell);
  (*cell) = NULL;
}

void freePlayground(Playground **playground) {
  CheckpointCell **cursor = &(*playground)->checkpointList.first;
  CheckpointCell **nextCursor = &(*playground)->checkpointList.first;
  while ((*nextCursor)->next != NULL) {
    *nextCursor = (*cursor)->next;
    free(cursor);
  }
  free(nextCursor);
  free(*playground);
  (*playground) = NULL;
}

void printCheckpointCell(CheckpointCell *checkpointCell) {
  printf("(x%f, y%f)\n", checkpointCell->pos.x, checkpointCell->pos.y);
}

void printCheckpointList(Playground *playground) {
  CheckpointCell *cursor = playground->checkpointList.first;
  if (cursor == NULL)
    printf("Liste de checkpoints vide !");
  else {
    printf("(");
    while (cursor->next != NULL) {
      printCheckpointCell(cursor);
      printf(",");
      cursor = cursor->next;
    }
    printCheckpointCell(cursor);
    printf(")\n\n");
  }
}

CheckpointCell * convertStringToCheckpoint(char string[]) {
  char strCoordinateX[MAX_SIZE], strCoordinateY[MAX_SIZE], strRadius[MAX_SIZE];
  unsigned int i = 0, j = 0, strLength = strlen(string);

  /* Lecture de la coordonnee X */
  while (string[i] != ',' && i < strLength) {
    strCoordinateX[j++] = string[i++];
  }
  strCoordinateX[j] = '\0';

  /* Lecture de la coordonnee Y */
  i++; /* On passe la virgule */
  if (i < strLength && string[i] != '\n') { /*Le dernier caractère de la chaine peut etre un retour chariot */
    j = 0;
    while (string[i] != ':' && i < strLength) {
      strCoordinateY[j++] = string[i++];
    }
    strCoordinateY[j] = '\0';
  } else
    return NULL;
 
  /* Lecture du rayon */
  i++; /* On passe les deux points */
  if (i < strLength && string[i] != '\n') {
    j = 0;
    while (i < strLength) {
      strRadius[j++] = string[i++];
    }
    strRadius[j] = '\0';
  } else
    return NULL;

  /* Conversion des valeurs */
  float convertedPosX = FLT_MAX, convertedPosY = FLT_MAX, convertedRadius = FLT_MAX;
  sscanf(strCoordinateX, "%f", &convertedPosX);
  sscanf(strCoordinateY, "%f", &convertedPosY);
  sscanf(strRadius, "%f", &convertedRadius);

  /* Vérification des valeurs */
  if (convertedPosX == FLT_MAX || convertedPosY == FLT_MAX || convertedRadius == FLT_MAX) //Si les valeurs n'ont pas été modifiées
    return NULL;
  if (convertedRadius <= 0)
    return NULL;

  /* On retourne le checkpoint créé */
  return initCheckpointCell(convertedPosX, convertedPosY, convertedRadius);
}

float convertStringToHeight(char lineBuffer[]) {
  float height = FLT_MAX;
  sscanf(lineBuffer, "%f", &height);
  if (height < 100)
    return FLT_MAX;
  return height;
}

Playground * readPlayground(Difficulty levelDifficulty, Size windowSize) {
  Playground *playground = initPlayground();
  CheckpointCell *checkpointCell;
  
  FILE *f;
  switch (levelDifficulty) {
    case NOOB:
      #ifdef OS_Windows /* Le séparateur n'est pas le même sur windows et linux */
        f = fopen("levels\\noob.lvl", "r");
      #else
        f = fopen("levels/noob.lvl", "r");
      #endif 
      playground->timer = 60;  
      break;
    case CAKE:
      #ifdef OS_Windows /* Le séparateur n'est pas le même sur windows et linux */
        f = fopen("levels\\gateau.lvl", "r");
      #else
        f = fopen("levels/gateau.lvl", "r");
      #endif
      playground->timer = 30;
      break;
    case OKLM:
      #ifdef OS_Windows /* Le séparateur n'est pas le même sur windows et linux */
        f = fopen("levels\\oklm.lvl", "r");
      #else
        f = fopen("levels/oklm.lvl", "r");
      #endif
      playground->timer = 20;
      break;
    case PROGAMER:
      #ifdef OS_Windows /* Le séparateur n'est pas le même sur windows et linux */
        f = fopen("levels\\progamer.lvl", "r");
      #else
        f = fopen("levels/progamer.lvl", "r");
      #endif
      playground->timer = 15;
      break;
    case HARDCORE:
      #ifdef OS_Windows /* Le séparateur n'est pas le même sur windows et linux */
        f = fopen("levels\\hardcore.lvl", "r");
      #else
        f = fopen("levels/hardcore.lvl", "r");
      #endif
      playground->timer = 10;
      break;
    case PERSO:
      #ifdef OS_Windows /* Le séparateur n'est pas le même sur windows et linux */
        f = fopen("levels\\perso.lvl", "r");
      #else
        f = fopen("levels/perso.lvl", "r");
      #endif
      playground->timer = 60;
      break;
  }

  FILE *errorfile;

  if (f == NULL) {
    /* S'il y a un problème lors de la lecture d'un terrain, on ne quitte pas le jeu mais on crée un fichier de crash */
    errorfile = fopen("crash_report.txt", "w");
    if (errorfile == NULL) exit(1);
    fprintf(errorfile, "Impossible d'ouvrir le fichier : Vérifiez que le fichier existe dans le dossier 'levels', que vous avez correctement écrit son nom du fichier et que vous possédez les droits en lecture.\n");
    fclose(errorfile);
    return NULL;
  } else {
    unsigned int lineNumber = 0;
    char lineBuffer[MAX_SIZE] = "";

    while (fgets(lineBuffer, MAX_SIZE, f) != NULL) {
      lineNumber++;

      if (lineNumber == 1) {
        // Récupération de la hauteur du terrain
        float height = convertStringToHeight(lineBuffer);

        if (height == FLT_MAX) {
          fclose(f);
          errorfile = fopen("crash_report.txt", "w");
          if (errorfile == NULL) exit(1);
          fprintf(errorfile, "Fichier - Erreur ligne %d : La hauteur du terrain doit être numérique et supérieure à 100.", lineNumber);
          fclose(errorfile);
          return NULL;
        } else {
          playground->halfCoordinatesSize.height = height;
          playground->halfCoordinatesSize.width = playground->halfCoordinatesSize.height*windowSize.width/windowSize.height; // Ratio de la fenêtre
        }
      } else {
        checkpointCell = convertStringToCheckpoint(lineBuffer);

        // Si le checkpoint est valable, on vérifie qu'il entre dans le terrain
        if (checkpointCell != NULL) {
          if ((checkpointCell->pos.x + checkpointCell->radius < playground->halfCoordinatesSize.width) 
            && (checkpointCell->pos.x - checkpointCell->radius > -playground->halfCoordinatesSize.width)
            && (checkpointCell->pos.y + checkpointCell->radius < playground->halfCoordinatesSize.height)
            && (checkpointCell->pos.y - checkpointCell->radius > -playground->halfCoordinatesSize.height)) {
            addCheckpoint(playground, checkpointCell);
          }
          /* S'il ne rentre pas dans le terrain, on ignore tout simplement ce checkpoint */

        } else { /* Si le checkpoint n'est pas valable on quitte le jeu */
          fclose(f);
          errorfile = fopen("crash_report.txt", "w");
          if (errorfile == NULL) exit(1);
          fprintf(errorfile, "Fichier - Erreur ligne %d : Format de checkpoint incorrect\nFormat : x,y:r avec x,y coordonnées de l'origine et r rayon du checkpoint", lineNumber);
          fclose(errorfile);
          return NULL;
        }
      }
    }

    /* Il est inutile de lancer le jeu s'il n'y a pas de checkpoint */
    if (playground->nbCheckpoints < 3) {
      fclose(f);
      errorfile = fopen("crash_report.txt", "w");
      if (errorfile == NULL) exit(1);
      fprintf(errorfile, "Fichier - Le terrain doit contenir au moins 3 checkpoints\nFormat d'écriture d'un checkpoint : x,y:r avec x,y coordonnées de l'origine et r rayon du checkpoint. Vérifiez également que les checkpoints entrent bien dans le terrain.");
      fclose(errorfile);
      return NULL;
    }

    fclose(f);
  }
  
  return playground;
}

void addCheckpoint(Playground *playground, CheckpointCell *checkpointCell) {
  if (playground->checkpointList.last == NULL) {  /* Si le dernier est à null, alors le premier aussi, on "initialise" la file */
    playground->checkpointList.first = checkpointCell;
  } else {
    playground->checkpointList.last->next = checkpointCell;
  }
  playground->checkpointList.last = checkpointCell;
  playground->nbCheckpoints += 1;
  playground->nbCheckpointsRemaining += 1;
}

void deleteCheckpoint(Playground *playground) {
  /* TODO il manque quelque chose là : cas ou first->next == null, ou first == last */
  if (playground->checkpointList.first != NULL) {
    playground->checkpointList.first = playground->checkpointList.first->next;
    playground->nbCheckpointsRemaining -= 1;
  } else {
    fprintf(stderr, "Liste vide");
  }
}

CheckpointCell * getFirstCheckpoint(Playground *playground) {
  return playground->checkpointList.first;
}