#include <stdlib.h>
#include <stdio.h>

#include "../include/PlanUtils.h"

Point2D initPoint2D(float x, float y) {
	Point2D p;
	p.x = x;
	p.y = y;
	return p;
}

Vecteur2D initVecteur2D(float x, float y) {
	Vecteur2D v;
	v.x = x;
	v.y = y;
	return v;
}