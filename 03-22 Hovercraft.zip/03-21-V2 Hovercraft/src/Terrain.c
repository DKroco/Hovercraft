#include <stdlib.h>
#include <stdio.h>

#include "../include/Terrain.h"

Checkpoint initCheckpoint(int centerx, int centery, float rayon) {
	Checkpoint cp;
	cp.pos = initPoint2D(centerx, centery);
	cp.rayon = rayon;
	cp.collision = 0;
	return cp;
}

Terrain initTerrain(int nbCheckpoints) {
  Terrain t;
 	int i;
 	t.nbCheckpoints = nbCheckpoints;
 	for(i = 0; i < t.nbCheckpoints; i++){
 		t.checkpoints[i] = initCheckpoint(-100+100*i,-100,20.);
 	}
  return t;
}

/* Collision de l'hovercraft avec le checkpoint
Retourne 1 s'il y a collision */
int collisionHC(float hPosX, float hPosY, float cPosX, float cPosY, float rayon, float largeurHovercraft) {
	if(hPosX-largeurHovercraft < cPosX+rayon && 
		hPosX+largeurHovercraft > cPosX-rayon && 
		hPosY-(largeurHovercraft*1.9) < cPosY+rayon && 
		hPosY+(largeurHovercraft*1.9) > cPosY-rayon)
		return 1;
	else
		return 0;
}

/* Collision de l'hovercraft avec le mur
Retourne 1 s'il y a collision */
CollisionResult testCollisionWall(float hPosX, float hPosY, unsigned int windowWidth, unsigned int windowHeight) {
	//TODO : faire en sorte que la collision prenne en compte la rotation de l'hovercraft (il est plus haut que large)
  if (hPosX+25 >= INTERVAL) {
  	if (hPosY+25 >= INTERVAL*windowHeight/windowWidth)
  		return CWALL_TOP_RIGHT;
  	else if (hPosY-25 <= -INTERVAL*windowHeight/windowWidth)
  		return CWALL_BOTTOM_RIGHT;
  	else
    	return CWALL_RIGHT;
  }else if (hPosX-25 <= -INTERVAL) {
    if (hPosY+25 >= INTERVAL*windowHeight/windowWidth)
  		return CWALL_TOP_LEFT;
  	else if (hPosY-25 <= -INTERVAL*windowHeight/windowWidth)
  		return CWALL_BOTTOM_LEFT;
  	else
    	return CWALL_LEFT;
  }
  if (hPosY+25 >= INTERVAL*windowHeight/windowWidth)
    return CWALL_TOP;
  else if (hPosY-25 <= -INTERVAL*windowHeight/windowWidth)
    return CWALL_BOTTOM;

  return NO_COLLISION;
}