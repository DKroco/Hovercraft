#ifndef PLANUTILS_H
#define PLANUTILS_H

typedef struct {
	float x;
	float y;
} Point2D;

typedef Point2D Vecteur2D;

Point2D initPoint2D(float x, float y);
Vecteur2D initVecteur2D(float x, float y);

#endif