#ifndef TERRAIN_H
#define TERRAIN_H

#include "PlanUtils.h"

#define INTERVAL 550.0 // Max des coordonnées x, définit le système orthogonal du jeu

typedef struct {
	Point2D pos;
	float rayon;
	int collision;
} Checkpoint;

typedef struct {
 	int nbCheckpoints;
 	Checkpoint checkpoints[10]; //TODO : Modifier ça ??
} Terrain;
 
typedef enum {
  NO_COLLISION ,
  CWALL_LEFT,
  CWALL_RIGHT,
  CWALL_TOP,
  CWALL_BOTTOM,
  CWALL_TOP_LEFT,
  CWALL_TOP_RIGHT,
  CWALL_BOTTOM_LEFT,
  CWALL_BOTTOM_RIGHT,
 // CWALL_TOUT_DROIT,
} CollisionResult; //TODO trouver un autre nom

Checkpoint initCheckpoint(int centerx, int centery, float rayon);
Terrain initTerrain(int nbCheckpoints);
int collisionHC(float hPosX, float hPosY, float cPosX, float cPosY, float rayon, float largeurHovercraft);
CollisionResult testCollisionWall(float hPosX, float hPosY, unsigned int windowWidth, unsigned int windowHeight);

#endif