#include <stdlib.h>
#include <stdio.h>

#include "../include/Hovercraft.h"

Hovercraft initHovercraft(float posx, float posy) {
	Hovercraft hc;
	hc.pos = initPoint2D(posx, posy);
	hc.largeur = 15.;
	hc.rotation = 0.;
	hc.vitesseMax = 5; //TODO Modifier ça
	hc.currentVitesse = 0;
	hc.direction = initVecteur2D(0, 0);
	hc.mouvement = initVecteur2D(0, 0);
	return hc;
}

