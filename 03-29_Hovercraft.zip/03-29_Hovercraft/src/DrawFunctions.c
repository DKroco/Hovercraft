#include <stdlib.h>
#include <stdio.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <math.h>

#include "../include/DrawFunctions.h"

void dessinCarre(int full) {
  if (full == 1)
    glBegin(GL_QUADS);
  else
    glBegin(GL_LINE_LOOP);
  
  glVertex2f(-0.5,0.5); 
  glVertex2f(0.5,0.5);
  glVertex2f(0.5,-0.5);
  glVertex2f(-0.5,-0.5);
    
  glEnd();
}

void dessinCercle(int full) {
  int i;
  float angle;
  if(full == 1) 
    glBegin(GL_POLYGON);
  else 
    glBegin(GL_LINE_LOOP);

    for(i = 0; i < 100; i++){
      angle = i*PI*2/100;
      glVertex2f(cos(angle),sin(angle));
    }
  glEnd();
}

void dessinCarreBordRond(int full) {
  glPushMatrix();
    glTranslatef(-0.25,0.25,0);
    glScalef(0.25,0.25,1);
    dessinCercle(1);
  glPopMatrix();

  glPushMatrix();
    glTranslatef(0.25,0.25,0);
    glScalef(0.25,0.25,1);
    dessinCercle(1);
  glPopMatrix();

  glPushMatrix();
    glTranslatef(0.25,-0.25,0);
    glScalef(0.25,0.25,1);
    dessinCercle(1);
  glPopMatrix();

  glPushMatrix();
    glTranslatef(-0.25,-0.25,0);
    glScalef(0.25,0.25,1);
    dessinCercle(1);
  glPopMatrix();

  glPushMatrix();
    glScalef(1,0.5,1);
    dessinCarre(1);
  glPopMatrix();

  glPushMatrix();
    glScalef(0.5,1,1);
    dessinCarre(1);
  glPopMatrix();
}

void dessinHovercraft() {
  // les boués
  glPushMatrix();
    glColor3f(0.4,0.4,0.45);
    glBegin(GL_QUADS);
      glVertex2f(-1.015,0.6);
      glVertex2f(-0.35,1.65);
      glVertex2f(0.35,1.65);
      glVertex2f(1.015,0.6);
    glEnd();
    glPushMatrix();
      glScalef(2,2.,1.);
      dessinCarreBordRond(1);
    glPopMatrix();
    glPushMatrix();
      glTranslatef(0,-0.9,0); 
      glScalef(2,2.,1.);
      dessinCarreBordRond(1);
    glPopMatrix();
  glPopMatrix();


  // la partie bleue claire
  glPushMatrix();
    glColor3f(0.45,0.8,1);
    glBegin(GL_POLYGON);
      glVertex2f(-0.75,0);
      glVertex2f(-0.75,0.5);
      glVertex2f(-0.15,1.5);
      glVertex2f(0.15,1.5);
      glVertex2f(0.75,0.5);
      glVertex2f(0.75,0);
    glEnd();
    glPushMatrix();
      glTranslatef(0,-0.25,0);
      glScalef(1.5,1.5,1.);
      dessinCarreBordRond(1);
    glPopMatrix();
    glPushMatrix();
      glTranslatef(0,-1,0);
      glScalef(1.5,1.5,1.);
      dessinCarreBordRond(1);
    glPopMatrix();
  glPopMatrix();

  // l'intérieur
  glPushMatrix();
    glColor3f(0.1,0.3,0.5);
    glBegin(GL_POLYGON);
      glVertex2f(-0.15,1.);
      glVertex2f(-0.55,0.5);
      glVertex2f(-0.55,-1.5);
      glVertex2f(0.55,-1.5);
      glVertex2f(0.55,0.5);
      glVertex2f(0.15,1);
      glVertex2f(0.15,1.5);
      glVertex2f(-0.15,1.5);
    glEnd();
    glColor3f(0.9,0.9,1);
    glBegin(GL_QUADS);
      glVertex2f(-0.4,0.25);
      glVertex2f(-0.4,-1.15);
      glVertex2f(0.4,-1.15);
      glVertex2f(0.4,0.25);
    glEnd();
    glColor3f(0.9,0.9,1);
    glBegin(GL_QUADS);
      glVertex2f(-0.4,0.25);
      glVertex2f(0.4,0.25);
      glVertex2f(0.05,0.75);
      glVertex2f(-0.05,0.75);
    glEnd();
    glColor3f(0.1,0.1,0.1);
    glBegin(GL_QUADS);
      glVertex2f(-0.3,0.25);
      glVertex2f(-0.3,-1.15);
      glVertex2f(0.3,-1.15);
      glVertex2f(0.3,0.25);
    glEnd();
  glPopMatrix();

  // Les ronds
  glPushMatrix();
    glPushMatrix();
      glColor3f(0.9,0.6,0.4);
      glTranslatef(0,-0.1,0);
      glScalef(0.2,0.2,1.);
      dessinCercle(1);
    glPopMatrix();

    glPushMatrix();
      glColor3f(0.3,0.3,0.4);
      glTranslatef(0,-1.75,0);
      glScalef(0.35,0.225,1.);
      dessinCercle(1);
    glPopMatrix();
    
    glPushMatrix();
     glColor3f(0.95,0.95,1);
      glTranslatef(0,-1.9,0);
      glScalef(0.3,0.175,1.);
      dessinCercle(1);
    glPopMatrix();
  glPopMatrix();
}

void dessinCheckpoint(int touche) {
  glPushMatrix();
    glPushMatrix();
      glColor3f(0.56,0.33,0);
      glScalef(2.25,0.5,1.);
      dessinCarreBordRond(1);
    glPopMatrix();
    glColor3f(1,1,1);
    glBegin(GL_QUADS);
      glVertex2f(-1,-0.15);
      glVertex2f(-1,0.15);
      glVertex2f(-0.5,0.15);
      glVertex2f(-0.5,-0.15);
    glEnd();
    glColor3f(0.98,0.78,0.17);
    glBegin(GL_QUADS);
      glVertex2f(-0.5,-0.15);
      glVertex2f(-0.5,0.15);
      glVertex2f(0.5,0.15);
      glVertex2f(0.5,-0.15);
    glEnd();
    glColor3f(0.91,0.66,0);
    glBegin(GL_QUADS);
      glVertex2f(0.5,-0.15);
      glVertex2f(0.5,0.15);
      glVertex2f(1,0.15);
      glVertex2f(1,-0.15);
    glEnd();
  glPopMatrix();
}

void dessinPieceFace() {
  glPushMatrix();
    glPushMatrix();
      glColor3f(0.56,0.33,0);
      glScalef(1.,1.05,1.);
      dessinCercle(1);
    glPopMatrix();
    glPushMatrix();
      glColor3f(1,0.83,0.17);
      glScalef(0.9,0.95,1.);
      dessinCercle(1);
    glPopMatrix();
    glPushMatrix();
      glColor3f(0.91,0.66,0);
      glScalef(0.65,0.7,1.);
      dessinCercle(1);
    glPopMatrix();
    glPushMatrix();
      glColor3f(0.98,0.78,0.17);
      glScalef(0.55,0.6,1.);
      dessinCercle(1);
    glPopMatrix();
    glPushMatrix();
      glColor3f(0.91,0.66,0);
      glTranslatef(-0.05,0,0);
      glScalef(0.135,0.435,1.);
      dessinCarre(1);
    glPopMatrix();
    glPushMatrix();
      glColor3f(1,1,1);
      glScalef(0.115,0.415,1.);
      dessinCarre(1);
    glPopMatrix();
  glPopMatrix();
}

void dessinBoussole(){
  glPushMatrix();
    glPushMatrix();
      glTranslatef(0, 1., 0);
      glScalef(0.1,0.55,1.);
      glColor3f(0.5,0.5,0.5);
      dessinCarre(1);
    glPopMatrix();
    glPushMatrix();
      glTranslatef(0, 1.25, 0);
      glScalef(0.15,0.15,1.);
      glColor3f(0.5,0.5,0.5);
      dessinCercle(1);
    glPopMatrix();
    glPushMatrix();
      glColor3f(1.,1.,1.);
      dessinCercle(1);
      glScalef(0.8,0.8,1.);
      glColor3f(0.1,0.,0.);
      dessinCercle(1);
      glScalef(0.2,0.2,1.);
      glColor3f(0.5,0.5,1.);
      dessinCercle(1);
    glPopMatrix();
    
  glPopMatrix();

}

void dessinFleche(){
  glPushMatrix();
      glTranslatef(0.3, 0, 0);
      glScalef(0.8,0.1,1.);
      glColor3f(1,1,0.5);
      dessinCarre(1);
  glPopMatrix();
  glPushMatrix();
      glTranslatef(-0.3, 0, 0);
      glScalef(0.8,0.1,1.);
      
      glColor3f(0,0,0.5);
      dessinCarre(1);
  glPopMatrix();
  

  
}