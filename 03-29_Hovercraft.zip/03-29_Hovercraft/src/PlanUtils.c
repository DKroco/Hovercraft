#include <stdlib.h>
#include <stdio.h>

#include "../include/PlanUtils.h"

Point2D initPoint2D(float x, float y) {
	Point2D p;
	p.x = x;
	p.y = y;
	return p;
}

Vecteur2D initVecteur2D(float x, float y) {
	Vecteur2D v;
	v.x = x;
	v.y = y;
	return v;
}

Vecteur2D updateVecteur2D(float x, float y) {
	Vecteur2D v;
	v.x = x;
	v.y = y;
	return v;
}

Vecteur2D addVectors(Vecteur2D u, Vecteur2D v) {
    return initVecteur2D(u.x + v.x, u.y + v.y);
}

Vecteur2D subVectors(Vecteur2D u, Vecteur2D v) {
    return initVecteur2D(u.x - v.x, u.y - v.y);
}

Vecteur2D multVector(Vecteur2D u, float a) {
    return initVecteur2D(u.x * a, u.y * a);
}

Vecteur2D divVector(Vecteur2D u, float a) {
    return initVecteur2D(u.x / a, u.y / a);
}

float dotProduct(Vecteur2D u, Vecteur2D v) {
    return u.x * v.x + u.y * v.y;
}

float sqrNorm(Vecteur2D v) {
    return dotProduct(v, v);
}

float norm(Vecteur2D v) {
    return sqrt(sqrNorm(v));
}

Vecteur2D normalize(Vecteur2D v) {
    return divVector(v, norm(v));
}


