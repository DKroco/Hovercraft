#include <SDL/SDL.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <SDL/SDL_image.h>

#include "../include/DrawFunctions.h"
#include "../include/Hovercraft.h"
#include "../include/PlanUtils.h"
#include "../include/Terrain.h"

//TODO Faire des variables pour les vitesses/rotations appliquées (fichier de config)

/* Nombre de bits par pixel de la fenêtre */
static const unsigned int BIT_PER_PIXEL = 32;

/* Nombre minimal de millisecondes separant le rendu de deux images */
static const Uint32 FRAMERATE_MILLISECONDS = 1000 / 60;

typedef enum {
  SOLO_GAME,
  MULTI_GAME,
  PAUSE,
  MENU
} GameMode; //TODO trouver un autre nom

/* Fonction de mise à jour du repère lorsqu'on redimensionne la fenêtre */
void reshape(unsigned int windowWidth, unsigned int windowHeight) {
	glViewport(0, 0, windowWidth, windowHeight);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(-INTERVAL, INTERVAL, -INTERVAL*windowHeight/windowWidth, INTERVAL*windowHeight/windowWidth);
}

/* Création de la fenêtre */
void setVideoMode(unsigned int windowWidth, unsigned int windowHeight) {
	if (NULL == SDL_SetVideoMode(windowWidth, windowHeight, BIT_PER_PIXEL, SDL_OPENGL /*| SDL_RESIZABLE*/)) {
		fprintf(stderr, "Impossible d'ouvrir la fenetre. Fin du programme.\n");
		exit(EXIT_FAILURE);
	}
}


/* Fonction de conversion de degré en radians */
float degToRad(float angleDegre) {
	return angleDegre*PI/180;
}

/* Fonction de conversion de radians en degres */
float radToDeg(float angleRadian) {
	return 180*angleRadian/PI;
}


/* Mise à jour de la rotation */
void updateRotation(int leftPressed, int rightPressed, Hovercraft *hc) {
	if (leftPressed) {
		hc->rotation += 5;
	} else if (rightPressed) {
		hc->rotation -= 5;
	}
}

/* Mise à jour de la vitesse et de la direction */
void updateSpeed(int upPressed, Hovercraft *hc) {
	if (upPressed) {
		if (hc->currentVitesse < hc->vitesseMax) {
			hc->currentVitesse += 0.1;
		}
		// Il n'y a que quand on accèlere que le changement de direction est pris en compte
		hc->direction.x = cos(degToRad(hc->rotation+90));
		hc->direction.y = sin(degToRad(hc->rotation+90));
	} else {
 		//TODO Gérer ça autrement ?
		if (hc->currentVitesse > 0.09) {
			hc->currentVitesse -= 0.09;
		} else {
			hc->currentVitesse = 0;
		}
	}
}

// Gestion des collisions
// Retourne 0 s'il n'y a pas eu de collision
int gestionCollision(Hovercraft *hc, int windowWidth, int windowHeight) {
	//int newAngle;
	CollisionResult collisionWall = testCollisionWall(hc->pos.x+hc->mouvement.x, hc->pos.y+hc->mouvement.y, windowWidth, windowHeight);
	if (collisionWall == NO_COLLISION)
		return 0;

	hc->direction.x = -cos(degToRad(hc->rotation+90));
	hc->direction.y = -sin(degToRad(hc->rotation+90));
  	// Mise à jour du mouvement
	hc->mouvement.x = -hc->mouvement.x*0.9 - (hc->direction.x*0.1)*hc->currentVitesse;
	hc->mouvement.y = -hc->mouvement.y*0.9 - (hc->direction.y*0.1)*hc->currentVitesse;
	hc->currentVitesse = 0;

	return 1;
}

void soloGameLoop() {

}

void rotationBoussole(float *alphaFleche, Terrain terrain, Hovercraft hovercraft){
	float x,y;

	Vecteur2D RepereVect = normalize(initVecteur2D(1000,0));

	x = terrain.checkpoints[0].pos.x - hovercraft.pos.x;
	y = terrain.checkpoints[0].pos.y - hovercraft.pos.y;
	Vecteur2D CheckpointVect = normalize(initVecteur2D(x,y));

	if(CheckpointVect.y < 0){
		*alphaFleche = -radToDeg(acos(dotProduct(CheckpointVect,RepereVect)));
	}else{
		*alphaFleche = radToDeg(acos(dotProduct(CheckpointVect,RepereVect)));
	}

}



int main(int argc, char** argv) {
//TODO Faire un fichier de configuration parsé au lancement du programme
	/* Dimensions de la fenêtre */
	unsigned int windowWidth  = 1280;
	unsigned int windowHeight = 720;
	float alpha = 0, rotation = 1, alphaFleche = 180.;
	float scale = 1.;
	int i, compteur;
	int loop = 1;
	int leftPressed = 0, rightPressed = 0, upPressed = 0;
	int gameMode = MENU;

	/* Initialisation de la SDL */
	if(-1 == SDL_Init(SDL_INIT_VIDEO)) {
		fprintf(stderr, "Impossible d'initialiser la SDL. Fin du programme.\n");
		return EXIT_FAILURE;
	}

	/* Ouverture d'une fenêtre et création d'un contexte OpenGL */
	setVideoMode(windowWidth, windowHeight);
	reshape(windowWidth, windowHeight);  

	/* Titre de la fenêtre */
	SDL_WM_SetCaption("Hovercraft!", NULL);

	Hovercraft hc = initHovercraft(0.,0.);
	Terrain terrain = initTerrain(5);

	GLuint idHovercraft;
	idHovercraft = glGenLists(1);
	glNewList(idHovercraft,GL_COMPILE);
		dessinHovercraft();   
	glEndList();

	GLuint idTerrain;
	idTerrain = glGenLists(1);
	glNewList(idTerrain,GL_COMPILE);
		glColor3f(0.1,0.5,1.);
		glBegin(GL_QUADS);  
			glVertex2f(INTERVAL,INTERVAL*windowHeight/windowWidth); 
			glVertex2f(-INTERVAL, INTERVAL*windowHeight/windowWidth);
			glVertex2f(-INTERVAL, -INTERVAL*windowHeight/windowWidth);
			glVertex2f(INTERVAL,-INTERVAL*windowHeight/windowWidth); 
		glEnd();  
	glEndList();

	GLuint idCheckpoint;
	idCheckpoint = glGenLists(1);
	glNewList(idCheckpoint,GL_COMPILE);
		dessinCheckpoint();   
	glEndList();

	GLuint idPiece;
	idPiece = glGenLists(1);
	glNewList(idPiece,GL_COMPILE);
		dessinPieceFace();   
	glEndList();

	// TODO : A REMETTRE
	// SDL_Surface* image = IMG_Load("img/playbutton.png");
 //    if(image == NULL) {
 //        fprintf(stderr, "Impossible de charger l'image %s\n", argv[1]);
 //        return EXIT_FAILURE;
 //    }

	/* Boucle d'affichage */
	while(loop) {
		//compteur = 0;
		/* Récupération du temps au début de la boucle */
		Uint32 startTime = SDL_GetTicks();

		/* Placer ici le code de dessin */
		glClear(GL_COLOR_BUFFER_BIT);
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();

		if (gameMode == MENU) {			
			glPushMatrix();
				glColor3f(0.1,0.5,1.);
				glBegin(GL_QUADS);  
					glVertex2f(-500, 50); 
					glVertex2f(-500, -50);
					glVertex2f(500, -50);
					glVertex2f(500,50); 
				glEnd();  
			glPopMatrix();			
			
			/* Echange du front et du back buffer : mise à jour de la fenêtre */
			SDL_GL_SwapBuffers();

			/* Boucle traitant les evenements */
			SDL_Event e;
			while(SDL_PollEvent(&e)) {
				if(e.type == SDL_QUIT) {
					loop = 0;
					break;
				}

				switch(e.type) {
				case SDL_MOUSEBUTTONDOWN:
					printf("clic en (%d, %d)\n", e.button.x, e.button.y);
					if (e.button.x/windowWidth*INTERVAL > -500 && e.button.x/windowWidth*INTERVAL < 500 
						&& e.button.y/windowWidth*INTERVAL*windowHeight/windowWidth > -50 && e.button.y/windowWidth*INTERVAL*windowHeight/windowWidth  < 50)
						gameMode = SOLO_GAME;
					break;

				/* Touche clavier */
				case SDL_KEYDOWN:
					switch (e.key.keysym.sym) {
					case SDLK_a:
		   			case SDLK_q: //TODO Attention, a modifier! Sur windows, le clavier est considéré comme qwerty...
		   			//TODO Ajouter ça dans le fichier de config? :D
				       	loop = 0;
				       	break;
				    default:
				       	break;
					}
					break;

				default:
				  	break;
				}
			}
		} else if (gameMode == SOLO_GAME) {
			updateRotation(leftPressed, rightPressed, &hc);
			updateSpeed(upPressed, &hc);

			// Mise à jour du mouvement
			hc.mouvement.x = hc.mouvement.x*0.9 + (hc.direction.x*0.1)*hc.currentVitesse;
			hc.mouvement.y = hc.mouvement.y*0.9 + (hc.direction.y*0.1)*hc.currentVitesse;

			gestionCollision(&hc, windowWidth, windowHeight);
			
			//Mise à jour de la position
			hc.pos.x += hc.mouvement.x;
			hc.pos.y += hc.mouvement.y;
				// Calcule si il y a collision entre l'hovercraft et un checkpoint
			// TODO : rendre plus propre
			for(i = 0; i < terrain.nbCheckpoints; i++){
				if(terrain.checkpoints[i].collision == 0){
					terrain.checkpoints[i].collision = collisionHC(hc.pos.x, hc.pos.y, terrain.checkpoints[i].pos.x, 
					terrain.checkpoints[i].pos.y, terrain.checkpoints[i].rayon, hc.largeur);
					if(terrain.checkpoints[i].collision == 1){
						compteur++;
						printf("Nombre de checkpoint restants %d\n",terrain.nbCheckpoints-compteur);
						if(compteur == terrain.nbCheckpoints)
							printf("Vous avez gagne !\n");
					}
				}
			}
			
			//Application du zoom
			glScalef(scale, scale, 1.0);
				glPushMatrix();
	  		// Affichage du terrain en fonction de la position de l'hovercraft
				//TODO On déplace pas le terrain si on voit un bord de la map ?
				glTranslatef(-hc.pos.x, -hc.pos.y, 0);
			  		//Affichage du terrain (carré bleu)
				glCallList(idTerrain);
					// affichage de tous les checkpoints
				for(i = 0; i < terrain.nbCheckpoints; i++){
					glPushMatrix();
						glTranslatef(terrain.checkpoints[i].pos.x, terrain.checkpoints[i].pos.y, 0);
						glRotatef(alpha,0.0,0.0,1.0);
						glScalef(terrain.checkpoints[i].rayon,terrain.checkpoints[i].rayon,1.);
						glColor3f(0,0,0.);
						if (!terrain.checkpoints[i].collision) {
							glCallList(idCheckpoint);
						}
					glPopMatrix();
				}
				alpha = alpha + rotation;
					
			glPopMatrix();
				glPushMatrix();
				glTranslatef(0, 0, 0);
				glRotatef(hc.rotation,0.0,0.0,1.);
				glScalef(hc.largeur,hc.largeur,1.);
				glCallList(idHovercraft);
			glPopMatrix();

			//Dessin de l'interface
			glPushMatrix();
				glTranslatef(INTERVAL-35, INTERVAL*windowHeight/windowWidth-35, 0);
				glScalef(20.,20.,1.);
				dessinBoussole();
				rotationBoussole(&alphaFleche,terrain,hc);
				glRotatef(alphaFleche,0.0,0.0,1.);
				dessinFleche();
			glPopMatrix();
			glPushMatrix();
				glTranslatef(INTERVAL-300, INTERVAL*windowHeight/windowWidth-35, 0);
				glScalef(20.,20.,1.);
				glCallList(idPiece);
			glPopMatrix();

			
			/* Echange du front et du back buffer : mise à jour de la fenêtre */
			SDL_GL_SwapBuffers();

			/* Boucle traitant les evenements */
			SDL_Event e;
			while(SDL_PollEvent(&e)) {
				if(e.type == SDL_QUIT) {
					loop = 0;
					break;
				}

				switch(e.type) {
				case SDL_MOUSEBUTTONDOWN:
					break;

				/* Touche clavier */
				case SDL_KEYDOWN:
					switch (e.key.keysym.sym) {
					case SDLK_a:
		   			case SDLK_q: //TODO Attention, a modifier! Sur windows, le clavier est considéré comme qwerty...
		   			//TODO Ajouter ça dans le fichier de config? :D
				       	loop = 0;
				       	break;
				    case SDLK_LEFT:
				       	leftPressed = 1;
				       	break;
				    case SDLK_RIGHT:
				       	rightPressed = 1;
				      	break;
				    case SDLK_UP:
				       	upPressed = 1;
				       	break;
				    default:
				       	break;
					}
					break;

				case SDL_KEYUP:
					switch (e.key.keysym.sym) {
					case SDLK_LEFT:
					   	leftPressed = 0;
					   	break;
					case SDLK_RIGHT:
					   	rightPressed = 0;
					   	break;
					case SDLK_UP:
					   	upPressed = 0;
					   	break;
					case SDLK_KP_PLUS:
					   	scale += 0.5;
					   	break;
					case SDLK_KP_MINUS:
					   	if (scale != 1.)
					   		scale -= 0.5;
					   	break;
					default:
					   	break;
					}
		    		break;

				default:
				  	break;
				}
			}

			
		} else {
			printf("BUG");
		}
		/* Calcul du temps écoulé */
		Uint32 elapsedTime = SDL_GetTicks() - startTime;

		/* Si trop peu de temps s'est écoulé, on met en pause le programme */
		if(elapsedTime < FRAMERATE_MILLISECONDS) {
			SDL_Delay(FRAMERATE_MILLISECONDS - elapsedTime);
		}
	}

	/* Liberation des ressources associées à la SDL */ 
	SDL_Quit();

	return EXIT_SUCCESS;
}
