#ifndef HOVERCRAFT_H
#define HOVERCRAFT_H

#include "PlanUtils.h"

typedef struct {
	Point2D pos;
	float largeur;
	float rotation;
	float vitesseMax;
	float currentVitesse; //TODO RENAME
	Vecteur2D direction;	//Direction vers laquelle l'hovercraft doit se diriger
	Vecteur2D mouvement;	//Mouvement auquel l'hovercraft va etre soumis
} Hovercraft;

Hovercraft initHovercraft(float posx, float posy);

#endif