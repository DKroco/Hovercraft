#ifndef DRAWFUNCTIONS_H
#define DRAWFUNCTIONS_H

#include "../include/Hovercraft.h"

#define PI 3.1415
#define CONST_SEGM 100

void dessinCarre(int full);
void dessinCercle(int full);
void dessinCarreBordRond(int full);

void dessinHovercraft();
void dessinCheckpoint();
void dessinPieceFace();
void dessinBoussole();
void dessinFleche();

#endif