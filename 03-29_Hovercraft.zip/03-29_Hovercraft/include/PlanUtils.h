#ifndef PLANUTILS_H
#define PLANUTILS_H

#include <math.h>

typedef struct {
	float x;
	float y;
} Point2D;

typedef Point2D Vecteur2D;

Point2D initPoint2D(float x, float y);
Vecteur2D initVecteur2D(float x, float y);
Vecteur2D updateVecteur2D(float x, float y);
Vecteur2D addVectors(Vecteur2D u, Vecteur2D v);
Vecteur2D subVectors(Vecteur2D u, Vecteur2D v);
Vecteur2D multVector(Vecteur2D u, float a);
Vecteur2D divVector(Vecteur2D u, float a);
float dotProduct(Vecteur2D u, Vecteur2D v);
float sqrNorm(Vecteur2D v);
float norm(Vecteur2D v);
Vecteur2D normalize(Vecteur2D v);

#endif