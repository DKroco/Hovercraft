#ifndef EVENTS_H
#define EVENTS_H

#include <SDL/SDL_mixer.h>
#include "Playground.h"
#include "Hovercraft.h"

/* Défini l'état actuel du jeu */
typedef enum {
  MENU,
  PAUSE,
  TUTORIAL,
  LEVEL_SELECTION,
  SOLO_GAME,
  MULTI_GAME,
  SOLO_WIN,
  MULTI_WIN_P1,
  MULTI_WIN_P2,
  EQUAL,
  GAME_OVER
} GameState;

/* Gestion des événements du menu */

void sound(Mix_Chunk *soundClic, Mix_Chunk *soundHover, int testSound, int *alreadyPlayed);

void handleMenuEvent(GameState *gameState, int *loop, int *breakingMenuLoop, int *multiplayers,Mix_Chunk *soundClic, Mix_Chunk *soundHover, int *alreadyPlayed);

void handleTutorialEvent(GameState *gameState, int *loop,Mix_Chunk *soundClic, Mix_Chunk *soundHover, int *alreadyPlayed);

void handlePauseEvent(GameState *gameState, int *loop, int *breakingMenuLoop, int multiplayers,Mix_Chunk *soundClic, Mix_Chunk *soundHover, int *alreadyPlayed);

void handleLevelSelectionEvent(GameState *gameState, int *loop, int *breakingMenuLoop, int multiplayers, Difficulty *levelDifficulty, int *seconds, int secondsReset, float *widthTimer, float widthTimerReset,Mix_Chunk *soundClic, Mix_Chunk *soundHover, int *alreadyPlayed);

void handleEndOfGameEvent(GameState *gameState, int *loop, int *breakingMenuLoop, int multiplayers, int *seconds, int secondsReset, float *widthTimer, float widthTimerReset,Mix_Chunk *soundClic, Mix_Chunk *soundHover, int *alreadyPlayed);

void handleSoloGameEvent(GameState *gameState, int *loop, float *scale, Player *player);

void handleMultiGameEvent(GameState *gameState, int *loop, float *scale, Player *playerOne, Player *playerTwo);

int checkSoloWin(Player *player, Hovercraft *hovercraft, Playground *playground, GameState *gameState, Mix_Chunk *soundCheckpoint, Mix_Chunk *soundWin);

int checkMultiWin(Player *playerOne, Player *playerTwo, Playground *playground, GameState *gameState, Mix_Chunk *soundCheckpoint, Mix_Chunk *soundWin, Mix_Chunk *soundGameOver);

#endif