#ifndef HOVERCRAFT_H
#define HOVERCRAFT_H

#include "Geometry.h"
#include "Playground.h"
#include <SDL/SDL.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_keysym.h>

/* Permet de définir les touches d'un joueur */
typedef struct {
	SDLKey up;
	SDLKey left;
	SDLKey right;
} Controller;

typedef struct {
	int upPressed;
	int leftPressed;
	int rightPressed;
} KeyPressed;

typedef struct {
	Point2D pos;
	float width;
	float rotation;
	float maxSpeed;
	float currentSpeed;
	Vector2D direction;	/* Direction vers laquelle l'hovercraft doit se diriger */
	Vector2D movement;	/* Mouvement auquel l'hovercraft va etre soumis */
} Hovercraft;

typedef struct {
	Hovercraft *hovercraft;
	Controller *controller;
	KeyPressed *keyPressed;
	int score;
} Player;

Player initPlayer(Hovercraft *hovercraft, Controller *controller);

Hovercraft * initHovercraft(float posx, float posy);

Controller * initController(SDLKey up, SDLKey left, SDLKey right);

KeyPressed * initKeyPress();

/* Mise à jour de la rotation 
Si leftPressed ou rightPressed = 1, alors l'hovercraft tournera */
void updateRotation(int leftPressed, int rightPressed, Hovercraft *hovercraft);

/* Mise à jour de la vitesse et de la direction 
Si upPressed = 1, on est soumis à l'acceleration*/
void updateSpeed(int upPressed, Hovercraft *hovercraft);

void updateHovercraft(Hovercraft *hovercraft, KeyPressed *keyPressed, Playground *playground, Size windowSize);

/* Vérification s'il y a une collision entre l'hovercraft et le checkpoint */
CollisionResult checkCheckpointCollision(Hovercraft *hovercraft, CheckpointCell *checkpoint);

/* Vérification s'il y a une collision entre deux hovercraft */
CollisionResult checkHovercraftCollision(Hovercraft *hovercraftOne, Hovercraft *hovercraftTwo);

/* Vérification s'il y a collision entre l'hovercraft et un des "murs" du terrain */
CollisionResult checkWallCollision(Point2D hovercraftPosition, Point2D hovercraftMovement, unsigned int windowWidth, unsigned int windowHeight, Size playgroundSize);

/* Gestion des collisions
 Retourne 0 s'il n'y a pas eu de collision */
int resolveCollision(Hovercraft *hovercraft, int windowWidth, int windowHeight, Playground *playground);

int resolveCollisionHovercraft(Hovercraft *hovercraftOne, Hovercraft *hovercraftTwo);

#endif