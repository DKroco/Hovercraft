#include <SDL/SDL.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>

#include "DrawFunctions.h"
#include "Hovercraft.h"
#include "Geometry.h"
#include "Playground.h"
#include "ListGeneration.h"
#include "Events.h"
#include "DrawScreenFunctions.h"

/*TODO Faire des variables pour les vitesses/rotations appliquées (fichier de config) */
/*TODO Mettre les bons checkpoints pour la bonne dificulté */

/* Nombre de bits par pixel de la fenêtre */
static const unsigned int BIT_PER_PIXEL = 32;

/* Nombre minimal de millisecondes separant le rendu de deux images */
static const Uint32 FRAMERATE_MILLISECONDS = 1000 / 60;

/* Fonction de mise à jour du repère lorsqu'on redimensionne la fenêtre */
void reshape(Size windowSize, Size wantedSize) {
	glViewport(0, 0, windowSize.width, windowSize.height);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(-wantedSize.width, wantedSize.width, 
		-wantedSize.height, wantedSize.height);
	/* On repasse sur le model view */
	glClear(GL_COLOR_BUFFER_BIT);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity(); 
}

/* Création de la fenêtre */
void setVideoMode(Size windowSize) {
	if (NULL == SDL_SetVideoMode(windowSize.width, windowSize.height, BIT_PER_PIXEL, SDL_OPENGL /*| SDL_RESIZABLE*/)) {
		fprintf(stderr, "Impossible d'ouvrir la fenetre. Fin du programme.\n");
		exit(EXIT_FAILURE);
	}
}

int functionMain(){
	/* Dimensions de la fenêtre */
	Size windowSize = initSize(1280, 720);

	float alpha = 0, rotation = 1, arrowAlpha = 180., arrowAlphaTwo = 180.;
	float scale = 1., widthTimerReset = windowSize.width/3, widthTimer = 0., timerDownInterval = 0., widthSquareReset = 20.;
	int loop = 1, seconds, secondsReset = 10;
	Uint32 beforeTime = 0;
	int newGame = 0; 

	GameState gameState = MENU;
	Size menuSize = initSize(200, 200*windowSize.width/windowSize.height);

	/* Initialisation SDL, ouverture de la fenêtre, et création d'un contexte OpenGL */
	if(-1 == SDL_Init(SDL_INIT_VIDEO)) {
		fprintf(stderr, "Impossible d'initialiser la SDL. Fin du programme.\n");
		return EXIT_FAILURE;
	}
	/* Initialisation de l'API Mixer*/
	if(-1 == Mix_OpenAudio(22050, MIX_DEFAULT_FORMAT, MIX_DEFAULT_CHANNELS, 4096)){
		fprintf(stderr, "Impossible d'initialiser la SDL_mixer. Fin du programme.\n");
		return EXIT_FAILURE;
	}

	setVideoMode(windowSize);
	reshape(windowSize, menuSize);  

	SDL_WM_SetCaption("Hovercraft | Vanessa BAR - Marion VILA | IMAC1", NULL);

	GLuint *printlists = generatePrintLists();
	GLuint *textures = generateTextures();

	Playground *playground;
	Difficulty levelDifficulty = NOOB;
	Player playerOne, playerTwo;
	Hovercraft *hovercraftOne, *hovercraftTwo;
	int multiplayers;

	/*Musique et sons*/
	/* TODO : faire une structure ou quelque chose comme ça ? */
	Mix_AllocateChannels(10);

	Mix_Volume(1,MIX_MAX_VOLUME/2);
	Mix_Music *music;
	music = Mix_LoadMUS("music/music.mp3");
	Mix_PlayMusic(music, -1);
	Mix_VolumeMusic(MIX_MAX_VOLUME);

	Mix_Chunk *soundClic;
	Mix_Chunk *soundHover;
	Mix_Chunk *soundCheckpoint;
	Mix_Chunk *soundWin;
	Mix_Chunk *soundGameOver;
	soundHover = Mix_LoadWAV("music/hover.ogg");
	soundClic = Mix_LoadWAV("music/clic.aiff");
	soundCheckpoint = Mix_LoadWAV("music/coin.ogg");
	soundWin = Mix_LoadWAV("music/win.ogg");
	soundGameOver = Mix_LoadWAV("music/game_over.ogg");
	
	int alreadyPlayed = 0;
	sound(soundClic,soundHover,0,&alreadyPlayed);
	

	while(loop) {
		Uint32 startTime = SDL_GetTicks();

		glClear(GL_COLOR_BUFFER_BIT);
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();

		switch (gameState) {
			case MENU:	
				reshape(windowSize, menuSize);

				/* Dessin du menu */
				drawTexturedScreen(textures[MENU_SCREEN], menuSize);
				SDL_GL_SwapBuffers();

				/* Traitement des événements */
				handleMenuEvent(&gameState, &loop, &newGame, &multiplayers,soundClic, soundHover,&alreadyPlayed);
				break;

			case TUTORIAL:
				drawTexturedScreen(textures[TUTORIAL_SCREEN], menuSize);
				SDL_GL_SwapBuffers();

				handleTutorialEvent(&gameState, &loop,soundClic, soundHover,&alreadyPlayed);
				break;

			case LEVEL_SELECTION:
				drawTexturedScreen(textures[LEVEL_SELECTION_SCREEN], menuSize);
				SDL_GL_SwapBuffers();

				handleLevelSelectionEvent(&gameState, &loop, &newGame, multiplayers, &levelDifficulty, &seconds, secondsReset, &widthTimer, widthTimerReset, soundClic, soundHover,&alreadyPlayed);
				break;

			case PAUSE:
				drawTexturedScreen(textures[PAUSE_SCREEN], playground->halfCoordinatesSize);
				SDL_GL_SwapBuffers();

				handlePauseEvent(&gameState, &loop, &newGame, multiplayers, soundClic, soundHover,&alreadyPlayed);
				break;

			case SOLO_GAME:
				if (newGame) {
					playground = readPlayground(levelDifficulty, windowSize); /* TODO c'est un peu sale de reload la map, surtout qu'elle a pas été utilisée avant... */
					reshape(windowSize, playground->halfCoordinatesSize); 

					secondsReset = playground->timer;
					seconds = secondsReset;
					timerDownInterval = widthTimer/(float)seconds;

					hovercraftOne = initHovercraft(0.,0.);
					playerOne = initPlayer(hovercraftOne, initController(SDLK_UP, SDLK_LEFT, SDLK_RIGHT));
					newGame = 0;
					multiplayers = 0;
				}

				if(timer(&startTime,&beforeTime,&seconds,&widthTimer,timerDownInterval) == 0){
					Mix_PlayChannel(-1,soundGameOver,0);
					gameState = GAME_OVER;
				}
				
				updateHovercraft(playerOne.hovercraft, playerOne.keyPressed, playground, windowSize);

				/* On regarde s'il y a collision avec le checkpoint actuel */
				if(checkSoloWin(&playerOne, playerOne.hovercraft, playground, &gameState, soundCheckpoint, soundWin)) {
					continue;
				}

				drawSoloGame(scale, &alpha, rotation, printlists, playground, playerOne.hovercraft);
				drawSoloInterface(&playerOne, playground, playerOne.hovercraft, printlists, &arrowAlpha, widthTimer, widthTimerReset, widthSquareReset);

				/* Echange du front et du back buffer : mise à jour de la fenêtre */
				SDL_GL_SwapBuffers();

				/* Boucle traitant les evenements */
				handleSoloGameEvent(&gameState, &loop, &scale, &playerOne);
				break;

			case SOLO_WIN:
				reshape(windowSize, menuSize);

				drawTexturedScreen(textures[SOLO_WIN_SCREEN], menuSize);
				SDL_GL_SwapBuffers();

				playerOne.score = 0;

				handleEndOfGameEvent(&gameState, &loop, &newGame, multiplayers, &seconds, secondsReset, &widthTimer, widthTimerReset, soundClic, soundHover,&alreadyPlayed);
				break;

			case GAME_OVER:
				reshape(windowSize, menuSize);

				drawTexturedScreen(textures[GAME_OVER_SCREEN], menuSize);
				SDL_GL_SwapBuffers();

				playerOne.score = 0;

				handleEndOfGameEvent(&gameState, &loop, &newGame, multiplayers, &seconds, secondsReset, &widthTimer, widthTimerReset, soundClic, soundHover,&alreadyPlayed);
				break;

			case MULTI_GAME:
				if (newGame) {
					playground = readPlayground(levelDifficulty, windowSize);

					reshape(windowSize, playground->halfCoordinatesSize); 
					hovercraftOne = initHovercraft(0., 0.);
					playerOne = initPlayer(hovercraftOne, initController(SDLK_UP, SDLK_LEFT, SDLK_RIGHT));

					hovercraftTwo = initHovercraft(0.,0.);
					#ifdef OS_Windows /* En OpenGl, le clavier windows est considéré comme qwerty TODO */
						playerTwo = initPlayer(hovercraftTwo, initController(SDLK_w, SDLK_a, SDLK_d)); 
					#else
						playerTwo = initPlayer(hovercraftTwo, initController(SDLK_z, SDLK_q, SDLK_d));
					#endif  
					
					newGame = 0;
					multiplayers = 1;
					playerOne.hovercraft->pos.x = -100;
					playerTwo.hovercraft->pos.x = 100;
				}
				
				updateHovercraft(playerOne.hovercraft, playerOne.keyPressed, playground, windowSize);
				updateHovercraft(playerTwo.hovercraft, playerTwo.keyPressed, playground, windowSize);

				//TODO updatePlayground();


				resolveCollisionHovercraft(playerOne.hovercraft, playerTwo.hovercraft);
				
				
				/* On regarde s'il y a collision avec le checkpoint actuel */
				if (checkMultiWin(&playerOne, &playerTwo, playground, &gameState, soundCheckpoint, soundWin, soundGameOver)) {
					continue;
				}

				drawMultiGame(scale, &alpha, rotation, printlists, playground, playerOne.hovercraft, playerTwo.hovercraft);
				drawMultiInterface(&playerOne, &playerTwo, playground, printlists, &arrowAlpha, &arrowAlphaTwo);

				/* Echange du front et du back buffer : mise à jour de la fenêtre */
				SDL_GL_SwapBuffers();

				/* Boucle traitant les evenements */
				handleMultiGameEvent(&gameState, &loop, &scale, &playerOne, &playerTwo);
				break;

			case MULTI_WIN_P1:
				reshape(windowSize, menuSize);

				drawTexturedScreen(textures[MULTI_WIN_P1_SCREEN], menuSize);
				SDL_GL_SwapBuffers();

				handleEndOfGameEvent(&gameState, &loop, &newGame, multiplayers, &seconds, secondsReset, &widthTimer, widthTimerReset, soundClic, soundHover,&alreadyPlayed);
				break;

			case MULTI_WIN_P2:
				reshape(windowSize, menuSize);

				drawTexturedScreen(textures[MULTI_WIN_P2_SCREEN], menuSize);
				SDL_GL_SwapBuffers();

				handleEndOfGameEvent(&gameState, &loop, &newGame, multiplayers, &seconds, secondsReset, &widthTimer, widthTimerReset, soundClic, soundHover,&alreadyPlayed);
				break;

			case EQUAL:
				reshape(windowSize, menuSize);

				drawTexturedScreen(textures[EQUAL_SCREEN], menuSize);
				SDL_GL_SwapBuffers();

				handleEndOfGameEvent(&gameState, &loop, &newGame, multiplayers, &seconds, secondsReset, &widthTimer, widthTimerReset, soundClic, soundHover,&alreadyPlayed);
				break;
		}
		
		Uint32 elapsedTime = SDL_GetTicks() - startTime;
		if(elapsedTime < FRAMERATE_MILLISECONDS) {
			SDL_Delay(FRAMERATE_MILLISECONDS - elapsedTime);
		}
	}
	Mix_FreeMusic(music);
	Mix_FreeChunk(soundClic);
	Mix_FreeChunk(soundHover);
	Mix_CloseAudio(); /* Fermeture de l'API pour le son */
	SDL_Quit();

	return EXIT_SUCCESS;
}


int main(int argc, char** argv) {
	functionMain();

	return 0;
}
