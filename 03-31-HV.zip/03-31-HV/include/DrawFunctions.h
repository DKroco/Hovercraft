#ifndef DRAWFUNCTIONS_H
#define DRAWFUNCTIONS_H

#include "../include/Hovercraft.h"

#define PI 3.1415
#define CONST_SEGM 100

void drawSquare(int full);
void drawCircle(int full);
void drawRoundSquare(int full);

void drawHovercraft();
void drawCheckpoint(int touched);
void drawPieceFace();
void drawCompass();
void drawArrow();

#endif