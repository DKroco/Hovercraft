#ifndef PLAYGROUND_H
#define PLAYGROUND_H

#include "Geometry.h"

#define INTERVAL 550.0 /* Max des coordonnées x, définit le système orthogonal du jeu */
#define MAX_SIZE 200 

typedef struct CheckpointCell {
	Point2D pos;
	float radius;
	int collision;
  struct CheckpointCell *next;
} CheckpointCell;

typedef CheckpointCell CheckpointList;

typedef struct {
 	int nbCheckpoints;
 	CheckpointList *checkpointList;
} Playground;
 
typedef enum {
  NO_COLLISION,
  CWALL_LEFT,
  CWALL_RIGHT,
  CWALL_TOP,
  CWALL_BOTTOM,
  CWALL_TOP_LEFT,
  CWALL_TOP_RIGHT,
  CWALL_BOTTOM_LEFT,
  CWALL_BOTTOM_RIGHT,
  CCHECKPOINT
} CollisionResult;

CheckpointCell * initCheckpointCell(int centerx, int centery, float radius);
Playground * initPlayground();
void printCheckpoint(const CheckpointCell *c);
void printCheckpointList(Playground *playground);
CheckpointCell * convertStringToCheckpoint(char string[]);
Playground * readPlayground(char filename[]);
void addCheckpoint(Playground *playground, CheckpointCell *checkpointCell);
void deleteCheckpoint(Playground *playground);
CheckpointCell * getFirstCheckpoint(Playground *playground);
int checkCheckpointCollision(float hovercraftPosX, float hovercraftPosY, float checkpointPosX, float checkpointPosY, float checkpointRadius, float hovercraftWidth);
CollisionResult checkWallCollision(float hovercraftPosX, float hovercraftPosY, unsigned int windowWidth, unsigned int windowHeight);

#endif