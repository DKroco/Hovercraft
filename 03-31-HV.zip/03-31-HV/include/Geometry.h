#ifndef GEOMETRY_H
#define GEOMETRY_H

#include <math.h>

typedef struct {
	float x;
	float y;
} Point2D;

typedef Point2D Vector2D;

Point2D initPoint2D(float x, float y);
Vector2D initVector2D(float x, float y);
Vector2D updateVector2D(float x, float y);
Vector2D addVectors(Vector2D u, Vector2D v);
Vector2D subVectors(Vector2D u, Vector2D v);
Vector2D multVector(Vector2D u, float a);
Vector2D divVector(Vector2D u, float a);
float dotProduct(Vector2D u, Vector2D v);
float sqrNorm(Vector2D v);
float norm(Vector2D v);
Vector2D normalize(Vector2D v);
int roundValue(float value);

#endif