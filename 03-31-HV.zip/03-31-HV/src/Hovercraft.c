#include <stdlib.h>
#include <stdio.h>

#include "../include/Hovercraft.h"

Hovercraft initHovercraft(float posx, float posy) {
	Hovercraft hovercraft;
	hovercraft.pos = initPoint2D(posx, posy);
	hovercraft.width = 15.;
	hovercraft.rotation = 0.;
	hovercraft.maxSpeed = 5; /* TODO Modifier ça */
	hovercraft.currentSpeed = 0;
	hovercraft.direction = initVector2D(0, 0);
	hovercraft.movement = initVector2D(0, 0);
	return hovercraft;
}