#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <float.h>

#include "../include/Playground.h"

CheckpointCell * initCheckpointCell(int centerx, int centery, float radius) {
	CheckpointCell *checkpointCell = malloc(sizeof(CheckpointCell));
  if (NULL == checkpointCell) {
    fprintf(stderr, "Erreur mémoire");
    exit(1);
  }
	checkpointCell->pos = initPoint2D(centerx, centery);
	checkpointCell->radius = radius;
	checkpointCell->collision = 0;
  checkpointCell->next = NULL;
	return checkpointCell;
}

Playground * initPlayground() {
  Playground *playground = malloc(sizeof(Playground));
 	if (playground == NULL) {
    fprintf(stderr, "Erreur mémoire");
    exit(1);
  }
 	playground->nbCheckpoints = 0;
 	playground->checkpointList = NULL;
  return playground;
} 

void printCheckpointCell(const CheckpointCell *checkpointCell) {
  printf("(%f,%f)\n", checkpointCell->pos.x, checkpointCell->pos.y);
}

void printCheckpointList(Playground *playground) {
  CheckpointList *cursor = playground->checkpointList;
  if (cursor == NULL)
    printf("Liste de checkpoints vide !");
  else {
    printf("(");
    while (cursor->next != NULL) {
      printCheckpointCell(cursor);
      printf(",");
      cursor = cursor->next;
    }
    printCheckpointCell(cursor);
    printf(")\n\n");
  }
}

CheckpointCell * convertStringToCheckpoint(char string[]) {
  char strCoordinateX[MAX_SIZE], strCoordinateY[MAX_SIZE], strRadius[MAX_SIZE];
  int i = 0, j = 0, strLength = strlen(string);

  /* Lecture de la coordonnee X */
  while (string[i] != ',' && i < strLength) {
    strCoordinateX[j++] = string[i++];
  }
  strCoordinateX[j] = '\0';

  /* Lecture de la coordonnee Y */
  i++; /* On passe la virgule */
  if (i < strLength && string[i] != '\n') { /*Le dernier caractère de la chaine peut etre un retour chariot */
    j = 0;
    while (string[i] != ':' && i < strLength) {
      strCoordinateY[j++] = string[i++];
    }
    strCoordinateY[j] = '\0';
  } else
    return NULL;
 
  /* Lecture du rayon */
  i++; /* On passe les deux points */
  if (i < strLength && string[i] != '\n') {
    j = 0;
    while (i < strLength) {
      strRadius[j++] = string[i++];
    }
    strRadius[j] = '\0';
    printf("Rayon %s\n", strRadius);
  } else
    return NULL;

  /* Conversion des valeurs */
  float convertedPosX = FLT_MAX, convertedPosY = FLT_MAX, convertedRadius = FLT_MAX;
  sscanf(strCoordinateX, "%f", &convertedPosX);
  sscanf(strCoordinateY, "%f", &convertedPosY);
  sscanf(strRadius, "%f", &convertedRadius);

  /* Vérification des valeurs */
  if (convertedPosX == FLT_MAX || convertedPosY == FLT_MAX || convertedRadius == FLT_MAX)
    return NULL;
  
  /* On retourne le checkpoint créé, on arrondi les valeurs */
  return initCheckpointCell(roundValue(convertedPosX), roundValue(convertedPosY), roundValue(convertedRadius));
}

Playground * readPlayground(char filename[]) {
  Playground *playground = initPlayground();
  CheckpointCell *checkpointCell;
  
  FILE *f = fopen(filename, "r");
  if (f == NULL) {
    fprintf(stderr, "Erreur ouverture fichier : Vérifiez le nom du fichier et que vous possédez les droits en lecture\n");
    exit(1);
  } else {
    int lineNumber = 0;
    char lineBuffer[MAX_SIZE] = "";

    while (fgets(lineBuffer, MAX_SIZE, f) != NULL) {
      lineNumber++;
      checkpointCell = convertStringToCheckpoint(lineBuffer);
      
      if (checkpointCell != NULL) {
        printCheckpointCell(checkpointCell);
        addCheckpoint(playground, checkpointCell);
      } else {
        fprintf(stderr, "Erreur ligne %d\nFormat de checkpoint : x,y:r avec x,y origine et r rayon.\n", lineNumber);
        exit(1);
      }
    }
    fclose(f);
  }
    
  return playground;
}

/* Ajout du checkpoint CheckpointCell dans la liste de checkpoint du terrain de jeu */
void addCheckpoint(Playground *playground, CheckpointCell *checkpointCell) {
  CheckpointList *first = playground->checkpointList;
  if (first != NULL) {
    checkpointCell->next = first;
  }
  playground->checkpointList = checkpointCell;
  playground->nbCheckpoints += 1;
}

/* Fonction de suppression du premier checkpoint de la liste de checkpoint */
void deleteCheckpoint(Playground *playground) {
  if (playground->checkpointList != NULL) {
    playground->checkpointList = playground->checkpointList->next;
    playground->nbCheckpoints -= 1;
  } else {
    printf("Liste vide !");
  }
}

CheckpointCell * getFirstCheckpoint(Playground *playground) {
  return playground->checkpointList;
}

/* Principe du jeu : Course - On doit toucher le premier checkpoint de la liste */

/* Collision de l'hovercraft avec le checkpoint
Retourne 1 s'il y a collision 
TODO : Mettre à jour avec un return noCollision ou CCheckpoint */
int checkCheckpointCollision(float hovercraftPosX, float hovercraftPosY, float checkpointPosX, float checkpointPosY, float checkpointRadius, float hovercraftWidth) {
	if(hovercraftPosX - hovercraftWidth < checkpointPosX + checkpointRadius && 
		hovercraftPosX + hovercraftWidth > checkpointPosX - checkpointRadius && 
		hovercraftPosY - (hovercraftWidth*1.9) < checkpointPosY + checkpointRadius && 
		hovercraftPosY + (hovercraftWidth*1.9) > checkpointPosY - checkpointRadius)
		return 1;
	else
		return 0;
}

/* Collision de l'hovercraft avec le mur
Retourne 1 s'il y a collision */
CollisionResult checkWallCollision(float hovercraftPosX, float hovercraftPosY, unsigned int windowWidth, unsigned int windowHeight) {
	/*TODO : faire en sorte que la collision prenne en compte la rotation de l'hovercraft (il est plus haut que large) */

  if (hovercraftPosX+25 >= INTERVAL) {
  	if (hovercraftPosY+25 >= INTERVAL*windowHeight/windowWidth)
  		return CWALL_TOP_RIGHT;
  	else if (hovercraftPosY-25 <= -INTERVAL*windowHeight/windowWidth)
  		return CWALL_BOTTOM_RIGHT;
  	else
    	return CWALL_RIGHT;
  } else if (hovercraftPosX-25 <= -INTERVAL) {
    if (hovercraftPosY+25 >= INTERVAL*windowHeight/windowWidth)
  		return CWALL_TOP_LEFT;
  	else if (hovercraftPosY-25 <= -INTERVAL*windowHeight/windowWidth)
  		return CWALL_BOTTOM_LEFT;
  	else
    	return CWALL_LEFT;
  }
  if (hovercraftPosY+25 >= INTERVAL*windowHeight/windowWidth)
    return CWALL_TOP;
  else if (hovercraftPosY-25 <= -INTERVAL*windowHeight/windowWidth)
    return CWALL_BOTTOM;

  return NO_COLLISION;
}