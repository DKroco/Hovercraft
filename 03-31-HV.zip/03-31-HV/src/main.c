#include <SDL/SDL.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <SDL/SDL_image.h>

#include "../include/DrawFunctions.h"
#include "../include/Hovercraft.h"
#include "../include/Geometry.h"
#include "../include/Playground.h"

/*TODO Faire des variables pour les vitesses/rotations appliquées (fichier de config) */

/* Nombre de bits par pixel de la fenêtre */
static const unsigned int BIT_PER_PIXEL = 32;

/* Nombre minimal de millisecondes separant le rendu de deux images */
static const Uint32 FRAMERATE_MILLISECONDS = 1000 / 60;

typedef enum {
  SOLO_GAME,
  MULTI_GAME,
  PAUSE,
  MENU
} GameMode; /*TODO trouver un autre nom */

/* Fonction de mise à jour du repère lorsqu'on redimensionne la fenêtre */
void reshape(unsigned int windowWidth, unsigned int windowHeight) {
	glViewport(0, 0, windowWidth, windowHeight);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(-INTERVAL, INTERVAL, -INTERVAL*windowHeight/windowWidth, INTERVAL*windowHeight/windowWidth);
}

/* Création de la fenêtre */
void setVideoMode(unsigned int windowWidth, unsigned int windowHeight) {
	if (NULL == SDL_SetVideoMode(windowWidth, windowHeight, BIT_PER_PIXEL, SDL_OPENGL /*| SDL_RESIZABLE*/)) {
		fprintf(stderr, "Impossible d'ouvrir la fenetre. Fin du programme.\n");
		exit(EXIT_FAILURE);
	}
}


/* Fonction de conversion de degré en radians */
float degToRad(float angleDegre) {
	return angleDegre*PI/180;
}

/* Fonction de conversion de radians en degres */
float radToDeg(float angleRadian) {
	return 180*angleRadian/PI;
}


/* Mise à jour de la rotation */
void updateRotation(int leftPressed, int rightPressed, Hovercraft *hovercraft) {
	if (leftPressed) {
		hovercraft->rotation += 5 - hovercraft->currentSpeed/2.5;
	} else if (rightPressed) {
		hovercraft->rotation -= 5 - hovercraft->currentSpeed/2.5;
	}
}

/* Mise à jour de la vitesse et de la direction */
void updateSpeed(int upPressed, Hovercraft *hovercraft) {
	if (upPressed) {
		if (hovercraft->currentSpeed < hovercraft->maxSpeed) {
				hovercraft->currentSpeed += 0.1;
		}
		/* Il n'y a que quand on accèlere que le changement de direction est pris en compte */
		hovercraft->direction.x = cos(degToRad(hovercraft->rotation+90));
		hovercraft->direction.y = sin(degToRad(hovercraft->rotation+90));
	} else {
 		/*TODO Gérer ça autrement ? */
		if (hovercraft->currentSpeed > 0.09) {
			hovercraft->currentSpeed -= 0.09;
		} else {
			hovercraft->currentSpeed = 0;
		}
	}
}

/* Gestion des collisions
 Retourne 0 s'il n'y a pas eu de collision */
int resolveCollision(Hovercraft *hovercraft, int windowWidth, int windowHeight) {
	CollisionResult collisionWall = checkWallCollision(hovercraft->pos.x+hovercraft->movement.x, hovercraft->pos.y+hovercraft->movement.y, windowWidth, windowHeight);
	if (collisionWall == NO_COLLISION)
		return 0;

	hovercraft->direction.x = -cos(degToRad(hovercraft->rotation+90));
	hovercraft->direction.y = -sin(degToRad(hovercraft->rotation+90));
  	/* Mise à jour du movement */
	hovercraft->movement.x = -hovercraft->movement.x*0.9 - (hovercraft->direction.x*0.1)*hovercraft->currentSpeed;
	hovercraft->movement.y = -hovercraft->movement.y*0.9 - (hovercraft->direction.y*0.1)*hovercraft->currentSpeed;
	hovercraft->currentSpeed = 0;

	return 1;
}

void soloGameLoop() {

}

void rotateCompass(float *arrowAlpha, Playground *playground, Hovercraft hovercraft){
	float x,y;

	Vector2D RepereVect = normalize(initVector2D(1000,0));

	x = getFirstCheckpoint(playground)->pos.x - hovercraft.pos.x;
	y = getFirstCheckpoint(playground)->pos.y - hovercraft.pos.y;
	Vector2D CheckpointVect = normalize(initVector2D(x,y));

	if(CheckpointVect.y < 0){
		*arrowAlpha = -radToDeg(acos(dotProduct(CheckpointVect,RepereVect)));
	}else{
		*arrowAlpha = radToDeg(acos(dotProduct(CheckpointVect,RepereVect)));
	}
}

/* Le chronometre */
int timer(Uint32 *currentTime, Uint32 *beforeTime, int *seconds, float *heightTimer, float timerDownInterval){
	if(*currentTime - *beforeTime > 1000){
		(*seconds)--;
		*heightTimer = (*heightTimer)-timerDownInterval;
		*beforeTime = *currentTime;
		return *seconds;
	}
	return -1;
}

int main(int argc, char** argv) {
/*TODO Faire un fichier de configuration parsé au lancement du programme */
	if (argc < 2) {
		printf("Erreur, nombre d'arguments incorrect.\nUsage : ./game levels/nomdulevel.lvl");
		return EXIT_FAILURE;
	}

	/* Dimensions de la fenêtre */
	unsigned int windowWidth  = 1280;
	unsigned int windowHeight = 720;
	float alpha = 0, rotation = 1, arrowAlpha = 180.;
	float scale = 1., heightTimerReset = 50., heightTimer = 0., timerDownInterval = 0., widthSquareReset = 20.;
	int loop = 1, seconds, secondsReset = 20;
	int leftPressed = 0, rightPressed = 0, upPressed = 0;
	int gameMode = MENU;
	Uint32 beforeTime = 0;
	seconds = secondsReset;
	heightTimer = heightTimerReset;
	timerDownInterval = heightTimer/(float)seconds;

	/* Initialisation de la SDL */
	if(-1 == SDL_Init(SDL_INIT_VIDEO)) {
		fprintf(stderr, "Impossible d'initialiser la SDL. Fin du programme.\n");
		return EXIT_FAILURE;
	}

	/* Ouverture d'une fenêtre et création d'un contexte OpenGL */
	setVideoMode(windowWidth, windowHeight);
	reshape(windowWidth, windowHeight);  

	/* Titre de la fenêtre */
	SDL_WM_SetCaption("Hovercraft!", NULL);

	Hovercraft hovercraft = initHovercraft(0.,0.);
	Playground *playground = readPlayground(argv[1]);
	/*addCheckpoint(playground, initCheckpointCell(40,20,20));
	addCheckpoint(playground, initCheckpointCell(50,-60,15));
	addCheckpoint(playground, initCheckpointCell(100,45,15));
	addCheckpoint(playground, initCheckpointCell(-75,120,15));*/
	printf("%d\n", playground->nbCheckpoints);
	//TODO Gèrer le cas qunand c'est vide

	GLuint idHovercraft;
	idHovercraft = glGenLists(1);
	glNewList(idHovercraft,GL_COMPILE);
		drawHovercraft();   
	glEndList();

	GLuint idPlayground;
	idPlayground = glGenLists(1);
	glNewList(idPlayground,GL_COMPILE);
		glColor3f(0.1,0.5,1.);
		glBegin(GL_QUADS);  
			glVertex2f(INTERVAL,INTERVAL*windowHeight/windowWidth); 
			glVertex2f(-INTERVAL, INTERVAL*windowHeight/windowWidth);
			glVertex2f(-INTERVAL, -INTERVAL*windowHeight/windowWidth);
			glVertex2f(INTERVAL,-INTERVAL*windowHeight/windowWidth); 
		glEnd();  
	glEndList();

	GLuint idCheckpoint;
	idCheckpoint = glGenLists(1);
	glNewList(idCheckpoint,GL_COMPILE);
		drawCheckpoint(0);   
	glEndList();

	GLuint idPiece;
	idPiece = glGenLists(1);
	glNewList(idPiece,GL_COMPILE);
		drawPieceFace();   
	glEndList();

	/* TODO : A REMETTRE */
	/* SDL_Surface* image = IMG_Load("img/playbutton.png");
    if(image == NULL) {
       	fprintf(stderr, "Impossible de charger l'image %s\n", argv[1]);
       	return EXIT_FAILURE;
    }*/

	/* Boucle d'affichage */
	while(loop) {
		/* Récupération du temps au début de la boucle */
		Uint32 startTime = SDL_GetTicks();

		/* Placer ici le code de draw */
		glClear(GL_COLOR_BUFFER_BIT);
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();

		if (gameMode == MENU) {			
			glPushMatrix();
				glColor3f(0.1,0.5,1.);
				glBegin(GL_QUADS);  
					glVertex2f(-500, 50); 
					glVertex2f(-500, -50);
					glVertex2f(500, -50);
					glVertex2f(500,50); 
				glEnd();  
			glPopMatrix();	
			
			/* Echange du front et du back buffer : mise à jour de la fenêtre */
			SDL_GL_SwapBuffers();

			/* Boucle traitant les evenements */
			SDL_Event e;
			while(SDL_PollEvent(&e)) {
				if(e.type == SDL_QUIT) {
					loop = 0;
					break;
				}

				switch(e.type) {
				case SDL_MOUSEBUTTONDOWN:
					printf("clic en (%d, %d)\n", e.button.x, e.button.y);
					if (e.button.x/windowWidth*INTERVAL > -500 && e.button.x/windowWidth*INTERVAL < 500 
						&& e.button.y/windowWidth*INTERVAL*windowHeight/windowWidth > -50 && e.button.y/windowWidth*INTERVAL*windowHeight/windowWidth  < 50)
						gameMode = SOLO_GAME;
					break;

				/* Touche clavier */
				case SDL_KEYDOWN:
					switch (e.key.keysym.sym) {
					case SDLK_a:
		   			case SDLK_q: /*TODO Attention, a modifier! Sur windows, le clavier est considéré comme qwerty... */
		   			/*TODO Ajouter ça dans le fichier de config? :D */
				       	loop = 0;
				       	break;
				    default:
				       	break;
					}
					break;

				default:
				  	break;
				}
			}
		} else if (gameMode == SOLO_GAME) {

			if(timer(&startTime,&beforeTime,&seconds,&heightTimer,timerDownInterval) == 0){
				printf("perdu\n");
				gameMode = MENU;
				seconds = secondsReset;
				heightTimer = heightTimerReset;
				continue;
			}
			

			updateRotation(leftPressed, rightPressed, &hovercraft);
			updateSpeed(upPressed, &hovercraft);

			/* Mise à jour du movement */
			hovercraft.movement.x = hovercraft.movement.x*0.9 + (hovercraft.direction.x*0.1)*hovercraft.currentSpeed;
			hovercraft.movement.y = hovercraft.movement.y*0.9 + (hovercraft.direction.y*0.1)*hovercraft.currentSpeed;

			resolveCollision(&hovercraft, windowWidth, windowHeight);
			
			/*Mise à jour de la position */
			hovercraft.pos.x += hovercraft.movement.x;
			hovercraft.pos.y += hovercraft.movement.y;

			/* On regarde s'il y a collision avec le checkpoint actuel */
			if (checkCheckpointCollision(hovercraft.pos.x, hovercraft.pos.y, getFirstCheckpoint(playground)->pos.x, 
					getFirstCheckpoint(playground)->pos.y, getFirstCheckpoint(playground)->radius, hovercraft.width)) {
				/* S'il y a collision, on supprime le checkpoint, et on augmente le compteur */
					deleteCheckpoint(playground);
					printf("Nombre de checkpoint restants %d\n",playground->nbCheckpoints);
					if(0 == playground->nbCheckpoints) {
						printf("Vous avez gagne !\n");
						gameMode = MENU;
						continue;
					}
			}
			
			/*Application du zoom */
			glScalef(scale, scale, 1.0);
				glPushMatrix();
	  		/* Affichage du playground en fonction de la position de l'hovercraft */
				/*TODO On déplace pas le playground si on voit un bord de la map ? */
				glTranslatef(-hovercraft.pos.x, -hovercraft.pos.y, 0);
			  		/*Affichage du playground (carré bleu) */
				glCallList(idPlayground);
					/* affichage du checkpoint */
				glPushMatrix();
					glTranslatef(getFirstCheckpoint(playground)->pos.x, getFirstCheckpoint(playground)->pos.y, 0);
					glRotatef(alpha,0.0,0.0,1.0);
					glScalef(getFirstCheckpoint(playground)->radius,getFirstCheckpoint(playground)->radius,1.);
					glColor3f(0,0,0.);
					glCallList(idCheckpoint);
				glPopMatrix();	
				alpha = alpha + rotation;
					
			glPopMatrix();
				glPushMatrix();
				glTranslatef(0, 0, 0);
				glRotatef(hovercraft.rotation,0.0,0.0,1.);
				glScalef(hovercraft.width,hovercraft.width,1.);
				glCallList(idHovercraft);
			glPopMatrix();

			/*Dessin de l'interface */
			glPushMatrix();
				glTranslatef(INTERVAL-35, INTERVAL*windowHeight/windowWidth-35, 0);
				glScalef(20.,20.,1.);
				drawCompass();
				rotateCompass(&arrowAlpha,playground,hovercraft);
				glRotatef(arrowAlpha,0.0,0.0,1.);
				drawArrow();
			glPopMatrix();
			glPushMatrix();
				glTranslatef(INTERVAL-300, INTERVAL*windowHeight/windowWidth-35, 0);
				glScalef(20.,20.,1.);
				glCallList(idPiece);
			glPopMatrix();

			glPushMatrix();
				glTranslatef(INTERVAL-100, INTERVAL*windowHeight/windowWidth-60, 0);
				glColor3f(0,0,0.);
				glBegin(GL_QUADS);
					glVertex2f(-22,heightTimerReset); 
					glVertex2f(22,heightTimerReset);
					glVertex2f(22,-2);
					glVertex2f(-22,-2);
				glEnd();
				glColor3f(0.99,0.8,0.);
				glBegin(GL_QUADS);
					glVertex2f(-20,heightTimer); 
					glVertex2f(20,heightTimer);
					glVertex2f(20,0);
					glVertex2f(-20,0);
				glEnd();
			glPopMatrix();

			/* Si on clique sur ce carré, on recommence la partie*/
			/* TODO : l'evenement */
			glPushMatrix();
				glTranslatef(INTERVAL-200, INTERVAL*windowHeight/windowWidth-35, 0);
				glColor3f(0.99,0.8,1.);
				glBegin(GL_QUADS);
					glVertex2f(-widthSquareReset,widthSquareReset); 
					glVertex2f(widthSquareReset,widthSquareReset);
					glVertex2f(widthSquareReset,-widthSquareReset);
					glVertex2f(-widthSquareReset,-widthSquareReset);
				glEnd();
			glPopMatrix();


			/* Echange du front et du back buffer : mise à jour de la fenêtre */
			SDL_GL_SwapBuffers();

			/* Boucle traitant les evenements */
			SDL_Event e;
			while(SDL_PollEvent(&e)) {
				if(e.type == SDL_QUIT) {
					loop = 0;
					break;
				}

				switch(e.type) {
				case SDL_MOUSEBUTTONDOWN:
					/* TODO : clic sur le carré, réinitialise */
					/*printf("clic2 en (%f, %f)\n", e.button.x/windowWidth*INTERVAL, e.button.y/windowWidth*INTERVAL*windowHeight/windowWidth);
					if (e.button.x/windowWidth*INTERVAL > INTERVAL+200-widthSquareReset && 
						e.button.x/windowWidth*INTERVAL < 1000 &&
						e.button.y/windowWidth*INTERVAL*windowHeight/windowWidth > INTERVAL*windowHeight/windowWidth-35+widthSquareReset && 
						e.button.y/windowWidth*INTERVAL*windowHeight/windowWidth  < INTERVAL*windowHeight/windowWidth-35-widthSquareReset)
						gameMode = MENU;*/
					break;

				/* Touche clavier */
				case SDL_KEYDOWN:
					switch (e.key.keysym.sym) {
					case SDLK_a:
		   			case SDLK_q: /*TODO Attention, a modifier! Sur windows, le clavier est considéré comme qwerty...*/
		   			/*TODO Ajouter ça dans le fichier de config? :D */
				       	loop = 0;
				       	break;
				    case SDLK_LEFT:
				       	leftPressed = 1;
				       	break;
				    case SDLK_RIGHT:
				       	rightPressed = 1;
				      	break;
				    case SDLK_UP:
				       	upPressed = 1;
				       	break;
				    default:
				       	break;
					}
					break;

				case SDL_KEYUP:
					switch (e.key.keysym.sym) {
					case SDLK_LEFT:
					   	leftPressed = 0;
					   	break;
					case SDLK_RIGHT:
					   	rightPressed = 0;
					   	break;
					case SDLK_UP:
					   	upPressed = 0;
					   	break;
					case SDLK_KP_PLUS:
					   	scale += 0.5;
					   	break;
					case SDLK_KP_MINUS:
					   	if (scale != 1.)
					   		scale -= 0.5;
					   	break;
					default:
					   	break;
					}
		    		break;

				default:
				  	break;
				}
			}

			
		} else {
			printf("BUG");
		}
		/* Calcul du temps écoulé */
		Uint32 elapsedTime = SDL_GetTicks() - startTime;

		/* Si trop peu de temps s'est écoulé, on met en pause le programme */
		if(elapsedTime < FRAMERATE_MILLISECONDS) {
			SDL_Delay(FRAMERATE_MILLISECONDS - elapsedTime);
		}
	}

	/* Liberation des ressources associées à la SDL */ 
	SDL_Quit();

	return EXIT_SUCCESS;
}
