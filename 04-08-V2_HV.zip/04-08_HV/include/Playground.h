#ifndef PLAYGROUND_H
#define PLAYGROUND_H

#include "Geometry.h"
#include "VarUtils.h"

/* Structure définissant une taille (largeur et hauteur) */
typedef struct Size {
  float width;
  float height;
} Size;

/* Cellule représentant un checkpoint */
typedef struct CheckpointCell {
	Point2D pos;
	float radius;
  struct CheckpointCell *next;
} CheckpointCell;

/* File de checkpoints, permettant de représenter tous les checkpoints d'un terrain */
typedef struct CheckpointList {
  CheckpointCell *first;
  CheckpointCell *last;
} CheckpointList;

/* Structure représentant un terrain de jeu */
typedef struct {
 	int nbCheckpoints;
 	CheckpointList checkpointList;
  Size halfCoordinatesSize; /* Représente la moitié de l'intervalle du système de coordonnées */
} Playground;
 
/* Enumération permettant de savoir quel type de collision a lieu */
typedef enum {
  NO_COLLISION,
  CWALL_LEFT,
  CWALL_RIGHT,
  CWALL_TOP,
  CWALL_BOTTOM,
  CWALL_TOP_LEFT,
  CWALL_TOP_RIGHT,
  CWALL_BOTTOM_LEFT,
  CWALL_BOTTOM_RIGHT,
  CCHECKPOINT
} CollisionResult;

typedef enum {
  NOOB,
  CAKE,
  OKLM,
  PROGAMER,
  HARDCORE,
  PERSO
} Difficulty;

/* Initialisation d'une structure Size */
Size initSize(float width, float height);

/* Initialisation d'une cellule checkpoint 
centerx et centery sont les coordonnées du centre du checkpoint */
CheckpointCell * initCheckpointCell(int centerx, int centery, float radius);

/* Initialisation d'un terrain */
Playground * initPlayground();

/* Libération de la mémoire allouée à une cellule */
void freeCheckpointCell(CheckpointCell **checkpointCell);

/* Libération de la mémoire allouée à un terrain */
void freePlayground(Playground **playground);

/* Affichage du checkpoint pointé par c */
void printCheckpoint(CheckpointCell *c);

/* Affichage des checkpoints d'un terrain */
void printCheckpointList(Playground *playground);

/* Conversion d'une chaîne de caractère en une cellule checkpoint */
CheckpointCell * convertStringToCheckpoint(char string[]);

/* Lecture d'un terrain dans le fichier filename, implique le calcul de la taille du terrain */
Playground * readPlayground(Difficulty levelDifficulty, Size windowSize);

/* Ajout d'un checkpoint à un terrain
Ajout en fin de liste */
void addCheckpoint(Playground *playground, CheckpointCell *checkpointCell);

/* Suppression d'un checkpoint à un terrain 
Suppression du premier checkpoint de la liste de checkpoints */
void deleteCheckpoint(Playground *playground);

/* Récupération du premier checkpoint de la liste de checkpoints du terrain */
CheckpointCell * getFirstCheckpoint(Playground *playground);

#endif