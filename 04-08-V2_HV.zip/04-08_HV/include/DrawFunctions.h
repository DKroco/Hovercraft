#ifndef DRAWFUNCTIONS_H
#define DRAWFUNCTIONS_H

#include "Hovercraft.h"
#include "VarUtils.h"

#define CONST_SEGM 100 /* Nombre de segments utilisés pour créer un cercle */

/* Dessin d'un carré de coté 1 
Si full = 1, le carré sera plein */
void drawSquare(int full);

/* Dessin d'un cercle de rayon 1 
Si full = 1, le cercle sera plein */
void drawCircle(int full);

/* Dessin d'un carré à bords ronds de coté 1 
Si full = 1, le carré sera plein */
void drawRoundSquare(int full);


/* Dessin de l'hovercraft */
void drawHovercraft();

/* Dessin d'un checkpoint */
void drawCheckpoint();

/* Dessin d'une boussole */
void drawCompass();

/* Dessin de la flèche de la boussole */
void drawArrow();

/* Dessin d'un carré texturé */
void drawSquareTextured();

#endif