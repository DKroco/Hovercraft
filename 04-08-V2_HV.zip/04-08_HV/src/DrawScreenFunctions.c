#include <SDL/SDL.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <SDL/SDL_image.h>

#include "DrawScreenFunctions.h"

/* Le chronometre */
int timer(Uint32 *currentTime, Uint32 *beforeTime, int *seconds, float *widthTimer, float timerDownInterval){
	if(*currentTime - *beforeTime > 1000){
		(*seconds)--;
		*widthTimer = (*widthTimer)-timerDownInterval;
		*beforeTime = *currentTime;
		return *seconds;
	}
	return -1;
}

void rotateCompass(float *arrowAlpha, Playground *playground, Hovercraft *hovercraft){
	float x,y;

	Vector2D RepereVect = normalize(initVector2D(1000,0));

	x = getFirstCheckpoint(playground)->pos.x - hovercraft->pos.x;
	y = getFirstCheckpoint(playground)->pos.y - hovercraft->pos.y;
	Vector2D CheckpointVect = normalize(initVector2D(x,y));

	if(CheckpointVect.y < 0){
		*arrowAlpha = -radToDeg(acos(dotProduct(CheckpointVect,RepereVect)));
	} else {
		*arrowAlpha = radToDeg(acos(dotProduct(CheckpointVect,RepereVect)));
	}
}

void drawSoloInterface(Playground *playground, Hovercraft *hovercraft, GLuint printlist[], float *arrowAlpha, float widthTimer, float widthTimerReset, float widthSquareReset) {
	float scale = playground->halfCoordinatesSize.width/15;
	float width = playground->halfCoordinatesSize.width;
	float height = playground->halfCoordinatesSize.height;

	/* Nécessité de tout exprimer en ratio */
	glPushMatrix();
		glTranslatef(0, height-(height/5),0);

		glPushMatrix();
			glTranslatef(width-(width/12), 0, 0);
			glScalef(scale, scale,1.);
			drawCompass();
			rotateCompass(arrowAlpha, playground, hovercraft);
			glRotatef(*arrowAlpha,0.0,0.0,1.);
			drawArrow();
		glPopMatrix();
		
		glPushMatrix();
			glTranslatef(width-3*(width/12), 0, 0);
			glScalef(scale, scale,1.);
			glCallList(printlist[ID_PIECE]);
		glPopMatrix();

		/* Utiliser les bazar canoniques, c'est pas très propre ça :/ */
		glPushMatrix();
			glTranslatef(-width/1.5, (-height*2)+50, 0);
			/* TODO : changer couleur quand le terrain sera la*/
			glColor3f(1,1,1);
			glBegin(GL_QUADS);
				glVertex2f(-2,7); 
				glVertex2f(widthTimerReset+2,7);
				glVertex2f(widthTimerReset+2,-2);
				glVertex2f(-2,-2);
			glEnd();
			glColor3f(0.99,0.8,0.);
			glBegin(GL_QUADS);
				glVertex2f(0,5); 
				glVertex2f(widthTimer,5);
				glVertex2f(widthTimer,0);
				glVertex2f(0,0);
			glEnd();
		glPopMatrix();
	
		/* Si on clique sur ce carré, on met pause*/
		/* TODO : l'evenement */
		glPushMatrix();
			glTranslatef(width-5*(width/12), 0, 0);
			glColor3f(0.99,0.8,1.);
			glScalef(scale*2, scale*2, 1.);
			drawSquare(1);
		glPopMatrix();
	glPopMatrix();
}

void drawTexturedScreen(GLuint textureId, Size size) {
	glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, textureId);

		glPushMatrix();
			glScalef(size.width*2, size.height*2, 1);
			glColor3f(1, 1, 1);
			drawSquareTextured();  
		glPopMatrix();

	glBindTexture(GL_TEXTURE_2D, 0);
    glDisable(GL_TEXTURE_2D);
}

void drawSoloGame(float scale, float *alpha, float rotation, GLuint *printlists, Playground *playground, Hovercraft *hovercraft) {
	/*Application du zoom */
	glScalef(scale, scale, 1.0);
		glPushMatrix();
		/* Affichage du playground en fonction de la position de l'hovercraft */
		/*TODO On déplace pas le playground si on voit un bord de la map ? */
		glTranslatef(-hovercraft->pos.x, -hovercraft->pos.y, 0);
	  		/*Affichage du playground (carré bleu) */
		glCallList(printlists[ID_PLAYGROUND]);
			/* affichage du checkpoint */
		glPushMatrix();
			glTranslatef(getFirstCheckpoint(playground)->pos.x, getFirstCheckpoint(playground)->pos.y, 0);
			glRotatef(*alpha,0.0,0.0,1.0);
			glScalef(getFirstCheckpoint(playground)->radius,getFirstCheckpoint(playground)->radius,1.);
			glColor3f(0,0,0.);
			glCallList(printlists[ID_CHECKPOINT]);
		glPopMatrix();	
		*alpha = *alpha + rotation;
			
	glPopMatrix();
		glPushMatrix();
		glTranslatef(0, 0, 0);
		glRotatef(hovercraft->rotation,0.0,0.0,1.);
		glScalef(hovercraft->width,hovercraft->width,1.);
		glCallList(printlists[ID_HOVERCRAFT]);
	glPopMatrix();
}

void drawMultiGame(float scale, float *alpha, float rotation, GLuint *printlists, Playground *playground, Hovercraft *hovercraftOne, Hovercraft *hovercraftTwo) {
	/*Application du zoom */
	glScalef(scale, scale, 1.0);
	glPushMatrix();
	  		/*Affichage du playground (carré bleu) */
		glCallList(printlists[ID_PLAYGROUND]);
			/* affichage du checkpoint */
		glPushMatrix();
			glTranslatef(getFirstCheckpoint(playground)->pos.x, getFirstCheckpoint(playground)->pos.y, 0);
			glRotatef(*alpha,0.0,0.0,1.0);
			glScalef(getFirstCheckpoint(playground)->radius,getFirstCheckpoint(playground)->radius,1.);
			glColor3f(0,0,0.);
			glCallList(printlists[ID_CHECKPOINT]);
		glPopMatrix();	
		*alpha = *alpha + rotation;
			
	glPopMatrix();

	glPushMatrix();
		glTranslatef(hovercraftOne->pos.x, hovercraftOne->pos.y, 0);
		glRotatef(hovercraftOne->rotation,0.0,0.0,1.);
		glScalef(hovercraftOne->width, hovercraftOne->width,1.);
		glCallList(printlists[ID_HOVERCRAFT]);
	glPopMatrix();

	glPushMatrix();
		glTranslatef(hovercraftTwo->pos.x, hovercraftTwo->pos.y, 0);
		glRotatef(hovercraftTwo->rotation,0.0,0.0,1.);
		glScalef(hovercraftTwo->width, hovercraftTwo->width,1.);
		glCallList(printlists[ID_HOVERCRAFT]);
	glPopMatrix();
}