#include <stdlib.h>
#include <stdio.h>

#include "Hovercraft.h"

Controller * initController(SDLKey up, SDLKey left, SDLKey right) {
	Controller *controller = malloc(sizeof(Controller)*1);
	controller->up = up;
	controller->left = left;
	controller->right = right;
	return controller;
}

Hovercraft * initHovercraft(float posx, float posy) {
	Hovercraft *hovercraft = malloc(sizeof(Hovercraft)*1);
	hovercraft->pos = initPoint2D(posx, posy);
	hovercraft->width = 15.;
	hovercraft->rotation = 0.;
	hovercraft->maxSpeed = 5; /* TODO Modifier ça */
	hovercraft->currentSpeed = 0;
	hovercraft->direction = initVector2D(0, 0);
	hovercraft->movement = initVector2D(0, 0);
	return hovercraft;
}

KeyPressed * initKeyPressed() {
	KeyPressed *keyPressed = malloc(sizeof(KeyPressed)*1);
	keyPressed->upPressed = 0;
	keyPressed->leftPressed = 0;
	keyPressed->rightPressed = 0;
	return keyPressed;
}

Player initPlayer(Hovercraft *hovercraft, Controller *controller) {
	Player player;
	player.hovercraft = hovercraft;
	player.controller = controller;
	player.keyPressed = initKeyPressed();
	return player;
}

void updateRotation(int leftPressed, int rightPressed, Hovercraft *hovercraft) {
	if (leftPressed) {
		hovercraft->rotation += 5 - hovercraft->currentSpeed/2.5;
	} else if (rightPressed) {
		hovercraft->rotation -= 5 - hovercraft->currentSpeed/2.5;
	}
}

void updateSpeed(int upPressed, Hovercraft *hovercraft) {
	if (upPressed) {
		if (hovercraft->currentSpeed < hovercraft->maxSpeed) {
				hovercraft->currentSpeed += 0.1;

		}
		printf("curr speed %f\n", hovercraft->currentSpeed);
		/* Il n'y a que quand on accèlere que le changement de direction est pris en compte */
		hovercraft->direction.x = cos(degToRad(hovercraft->rotation+90));
		hovercraft->direction.y = sin(degToRad(hovercraft->rotation+90));
	} else {
 		/*TODO Gérer ça autrement ? */
		if (hovercraft->currentSpeed > 0.09) {
			hovercraft->currentSpeed -= 0.09;
		} else {
			hovercraft->currentSpeed = 0;
		}
	}
}

void updateHovercraft(Hovercraft *hovercraft, KeyPressed *keyPressed, Playground *playground, Size windowSize) {
	updateRotation(keyPressed->leftPressed, keyPressed->rightPressed, hovercraft);
	updateSpeed(keyPressed->upPressed, hovercraft);

	/* Mise à jour du movement */
	hovercraft->movement.x = hovercraft->movement.x*0.9 + (hovercraft->direction.x*0.1)*hovercraft->currentSpeed;
	hovercraft->movement.y = hovercraft->movement.y*0.9 + (hovercraft->direction.y*0.1)*hovercraft->currentSpeed;

	resolveCollision(hovercraft, windowSize.width, windowSize.height, playground);
	
	/*Mise à jour de la position */
	hovercraft->pos.x += hovercraft->movement.x;
	hovercraft->pos.y += hovercraft->movement.y;
}

CollisionResult checkCheckpointCollision(Point2D hovercraftPosition, CheckpointCell *checkpoint, float hovercraftWidth) {
	float hovercraftPosX = hovercraftPosition.x;
	float hovercraftPosY = hovercraftPosition.y;

	float checkpointPosX = checkpoint->pos.x;
	float checkpointPosY = checkpoint->pos.y;
	float checkpointRadius = checkpoint->radius;

	if(hovercraftPosX - hovercraftWidth < checkpointPosX + checkpointRadius && 
		hovercraftPosX + hovercraftWidth > checkpointPosX - checkpointRadius && 
		hovercraftPosY - (hovercraftWidth*1.9) < checkpointPosY + checkpointRadius && 
		hovercraftPosY + (hovercraftWidth*1.9) > checkpointPosY - checkpointRadius)
		return CCHECKPOINT;
	else
		return NO_COLLISION;
}

CollisionResult checkWallCollision(Point2D hovercraftPosition, Point2D hovercraftMovement, unsigned int windowWidth, unsigned int windowHeight, Size playgroundSize) {
	/*TODO : faire en sorte que la collision prenne en compte la rotation de l'hovercraft (il est plus haut que large) */
  float hovercraftPosX = hovercraftPosition.x + hovercraftMovement.x; /* On anticipe le déplacement de l'hovercraft en ajoutant le mouvement à la position */
  float hovercraftPosY = hovercraftPosition.y + hovercraftMovement.y;

  float halfHeight = playgroundSize.height;
  float halfWidth = playgroundSize.width;

  if (hovercraftPosX+25 >= halfWidth) {
  	if (hovercraftPosY+25 >= halfHeight)
  		return CWALL_TOP_RIGHT;
  	else if (hovercraftPosY-25 <= -halfHeight)
  		return CWALL_BOTTOM_RIGHT;
  	else
    	return CWALL_RIGHT;
  } else if (hovercraftPosX-25 <= -halfWidth) {
    if (hovercraftPosY+25 >=  halfHeight)
  		return CWALL_TOP_LEFT;
  	else if (hovercraftPosY-25 <= -halfHeight)
  		return CWALL_BOTTOM_LEFT;
  	else
    	return CWALL_LEFT;
  }
  if (hovercraftPosY+25 >= halfHeight)
    return CWALL_TOP;
  else if (hovercraftPosY-25 <= -halfHeight)
    return CWALL_BOTTOM;

  return NO_COLLISION;
}

int resolveCollision(Hovercraft *hovercraft, int windowWidth, int windowHeight, Playground *playground) {
	CollisionResult collisionWall = checkWallCollision(hovercraft->pos, hovercraft->movement, windowWidth, windowHeight, playground->halfCoordinatesSize);
	if (collisionWall == NO_COLLISION)
		return 0;

	hovercraft->direction.x = -cos(degToRad(hovercraft->rotation+90));
	hovercraft->direction.y = -sin(degToRad(hovercraft->rotation+90));
  	/* Mise à jour du mouvement */
	hovercraft->movement.x = -hovercraft->movement.x*0.9 - (hovercraft->direction.x*0.1)*hovercraft->currentSpeed;
	hovercraft->movement.y = -hovercraft->movement.y*0.9 - (hovercraft->direction.y*0.1)*hovercraft->currentSpeed;
	hovercraft->currentSpeed = 0;

	return 1;
}