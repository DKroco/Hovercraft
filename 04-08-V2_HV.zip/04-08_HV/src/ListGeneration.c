#include <SDL/SDL.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <stdlib.h>
#include <stdio.h>
#include <ListGeneration.h>

/* Permet la création de toutes les listes d'affichages utilisées */
GLuint * generatePrintLists() {
	GLuint *printlists = malloc(sizeof(GLuint)*NB_PRINTLISTS);

	printlists[ID_HOVERCRAFT] = glGenLists(1);
	glNewList(printlists[ID_HOVERCRAFT], GL_COMPILE);
		drawHovercraft();   
	glEndList();

	printlists[ID_PLAYGROUND] = glGenLists(1);
	glNewList(printlists[ID_PLAYGROUND], GL_COMPILE);
		glColor3f(0.1,0.5,1.);
		glBegin(GL_QUADS);  
			/*glVertex2f(playground->halfCoordinatesSize.width, playground->halfCoordinatesSize.height); 
			glVertex2f(-playground->halfCoordinatesSize.width, playground->halfCoordinatesSize.height);
			glVertex2f(-playground->halfCoordinatesSize.width, -playground->halfCoordinatesSize.height);
			glVertex2f(playground->halfCoordinatesSize.width, -playground->halfCoordinatesSize.height); */
		glEnd();  
	glEndList();

	printlists[ID_CHECKPOINT] = glGenLists(1);
	glNewList(printlists[ID_CHECKPOINT], GL_COMPILE);
		drawCheckpoint();   
	glEndList();

	printlists[ID_PIECE] = glGenLists(1);
	glNewList(printlists[ID_PIECE], GL_COMPILE);
		drawCheckpoint();   
	glEndList();

	return printlists;
}

void freePrintlists(GLuint **printlists) {
	free(*printlists);
	(*printlists) = NULL;
}

GLenum getImgFormat(SDL_Surface *image) {
	GLenum format;
    switch(image->format->BytesPerPixel) {
        case 1:
            format = GL_RED;
            break;
        case 3:
            format = GL_RGB;
            break;
        case 4:
            format = GL_RGBA;
            break;
        default:
        	fprintf(stderr, "Format des pixels de l'image non pris en charge\n");
			exit(EXIT_FAILURE);
    }

    return format;
}

/* Ouverture de l'image imgPath */
SDL_Surface * loadImage(char imgPath[]) {
	SDL_Surface *image = IMG_Load(imgPath);
    if(image == NULL) {
        fprintf(stderr, "Impossible de charger l'image");
        exit(EXIT_FAILURE);
    }

    return image;
}

/* Permet de créer la texture engendrée par imgPath */
GLuint createTexture(char imgPath[]) {
	GLuint textureId;
    glGenTextures(1, &textureId);
    glBindTexture(GL_TEXTURE_2D, textureId);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

    /* TODO : Les deux fonctions retournent null s'il y a un pb, et on fait un fichier de crash */
    SDL_Surface *image = loadImage(imgPath);
    GLenum format = getImgFormat(image);

    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, image->w, image->h, 0, format, GL_UNSIGNED_BYTE, image->pixels);
    glBindTexture(GL_TEXTURE_2D, 0);
    
    SDL_FreeSurface(image);

    return textureId;
}

/* Permet la création de toutes les textures utilisées */
GLuint * generateTextures() {
	char * texturesPath[] = {"img/menu.png", "img/pause.png", "img/tuto.png", "img/levelSelection.png", "img/winSolo.png", "img/winMultiP1.png", "img/winMultiP2.png", "img/gameOver.png"};
	GLuint *textures = malloc(sizeof(GLuint)*NB_TEXTURES);

	int i;
	for (i = 0; i < NB_TEXTURES; i++) {
		textures[i] = createTexture(texturesPath[i]);
	}

	return textures;
}

void freeTextures(GLuint **textures) {
	free(*textures);
	(*textures) = NULL;
}