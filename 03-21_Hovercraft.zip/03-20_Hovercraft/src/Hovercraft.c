#include <stdlib.h>
#include <stdio.h>

#include "../include/Hovercraft.h"

Hovercraft initHovercraft(float posx, float posy) {
	Hovercraft hc;
	hc.pos = initPoint2D(posx, posy);
	hc.rotation = 0.;
	hc.vitesseMax = 5; //TODO Modifier ça
	hc.currentVitesse = 0;
	hc.direction = initVecteur2D(0, 0);
	hc.mouvement = initVecteur2D(0, 0);
	return hc;
}

/* Mise à jour de la rotation */
void updateRotation(int leftPressed, int rightPressed, Hovercraft *hc) {
	if (leftPressed) {
		hc->rotation += 5;
	} else if (rightPressed) {
		hc->rotation -= 5;
	}
}

/* Mise à jour de la vitesse et de la direction */
void updateSpeed(int upPressed, Hovercraft *hc) {
	if (upPressed) {
		if (hc->currentVitesse < hc->vitesseMax) {
			hc->currentVitesse += 0.1;
		}
		// Il n'y a que quand on accèlere que le changement de direction est pris en compte
		hc->direction.x = cos(degToRad(hc->rotation+90));
		hc->direction.y = sin(degToRad(hc->rotation+90));
	} else {
 		//TODO Gérer ça autrement ?
		if (hc->currentVitesse > 0.09) {
			hc->currentVitesse -= 0.09;
		} else {
			hc->currentVitesse = 0;
		}
	}
}

/* Fonction de conversion de degré en radians */
float degToRad(float angleDegre) {
	return angleDegre*PI/180;
}