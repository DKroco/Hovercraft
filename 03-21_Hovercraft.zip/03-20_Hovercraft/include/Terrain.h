#ifndef TERRAIN_H
#define TERRAIN_H

#include "PlanUtils.h"

#define INTERVAL 300.0 // Max des coordonnées x, définit le système orthogonal du jeu

typedef struct {
	Point2D pos;
	float rayon;
	int collision;
} Checkpoint;

typedef struct {
 	int nbCheckpoints;
 	Checkpoint Checkpoints[];
} Terrain;
 
typedef enum {
  NO_COLLISION ,
  CWALL_LEFT,
  CWALL_RIGHT,
  CWALL_TOP,
  CWALL_BOTTOM,
  CWALL_TOP_LEFT,
  CWALL_TOP_RIGHT,
  CWALL_BOTTOM_LEFT,
  CWALL_BOTTOM_RIGHT
} CollisionResult; //TODO trouver un autre nom

Checkpoint initCheckpoint(int centerx, int centery, float rayon);
//void initTerrain(int nb, Terrain *t);
int collisionHC(float hPosX, float hPosY, float cPosX, float cPosY, float rayon, float largeurHovercraft);
CollisionResult testCollisionWall(float hPosX, float hPosY, unsigned int windowWidth, unsigned int windowHeight);

#endif