#ifndef HOVERCRAFT_H
#define HOVERCRAFT_H

#include "PlanUtils.h"
#include "../include/DrawFunctions.h"
#include <math.h>

typedef struct {
	Point2D pos;
	float rotation;
	float vitesseMax;
	float currentVitesse; //TODO RENAME
	Vecteur2D direction;	//Direction vers laquelle l'hovercraft doit se diriger
	Vecteur2D mouvement;	//Mouvement auquel l'hovercraft va etre soumis
} Hovercraft;

Hovercraft initHovercraft(float posx, float posy);
void updateRotation(int leftPressed, int rightPressed, Hovercraft *hc);
void updateSpeed(int upPressed, Hovercraft *hc);
float degToRad(float angleDegre);

#endif