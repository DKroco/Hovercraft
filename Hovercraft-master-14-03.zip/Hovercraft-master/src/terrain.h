#ifndef TERRAIN_H
#define TERRAIN_H

// #include "planUtils.h"

typedef struct Checkpoint{
	Coordonnees* pos;
	float rayon;
} Checkpoint;

// typedef struct Terrain{
// 	int nbCheckpoints;
// 	struct Checkpoint[] Checkpoints;
// } Terrain;

Checkpoint * init_checkpoint(Coordonnees* pos, float rayon);
void dessinCheckpoint(int touche);
void dessinPieceFace();




#endif