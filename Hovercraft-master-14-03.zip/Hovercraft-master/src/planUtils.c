#include <stdlib.h>
#include <stdio.h>

#include "planUtils.h"



Coordonnees * init_coordonnees(int x, int y) {
	Coordonnees *c = malloc(1*sizeof(Coordonnees));
	c->x = x;
	c->y = y;
	return c;
}

Vecteur * init_vecteur(int x, int y) {
	Vecteur *v = malloc(1*sizeof(Vecteur));
	v->x = x;
	v->y = y;
	return v;
}

void dessinCarre(int full){
  if (full == 1)
    glBegin(GL_QUADS);
  else
    glBegin(GL_LINE_LOOP);
  
  glVertex2f(-0.5,0.5); 
  glVertex2f(0.5,0.5);
  glVertex2f(0.5,-0.5);
  glVertex2f(-0.5,-0.5);
    
  glEnd();
}


void dessinCercle(int full){
  int i;
  if(full == 1) glBegin(GL_TRIANGLE_FAN);
  else glBegin(GL_LINE_LOOP);
    glVertex2f(0,0); //point de d´epart
    for(i = 0; i <= CONST_SEGM; i++){
      glVertex2f(
        0+ (0.5 * cos(i * 2.0 * PI/CONST_SEGM)),
        0+ (0.5 * sin(i * 2.0 * PI/CONST_SEGM))
      ); 
    } 
  glEnd();
}

void dessinCarreBordRond(int full){
  glPushMatrix();
  glTranslatef(-0.25,0.25,0);
  glScalef(0.5,0.5,1);
  dessinCercle(full);
  glPopMatrix();

  glPushMatrix();
  glTranslatef(0.25,0.25,0);
  glScalef(0.5,0.5,1);
  dessinCercle(full);
  glPopMatrix();

  glPushMatrix();
  glTranslatef(0.25,-0.25,0);
  glScalef(0.5,0.5,1);
  dessinCercle(full);
  glPopMatrix();

  glPushMatrix();
  glTranslatef(-0.25,-0.25,0);
  glScalef(0.5,0.5,1);
  dessinCercle(full);
  glPopMatrix();

  glPushMatrix();
  glScalef(1,0.5,1);
  dessinCarre(1);
  glPopMatrix();

  glPushMatrix();
  glScalef(0.5,1,1);
  dessinCarre(1);
  glPopMatrix();
}