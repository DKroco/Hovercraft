#include <stdlib.h>
#include <stdio.h>

#include "terrain.h"

Checkpoint * init_checkpoint(Coordonnees* pos, float rayon) {
	Checkpoint *cp = malloc(1*sizeof(Checkpoint));
	cp->pos = pos;
	cp->rayon = rayon;
	return cp;
}


void dessinCheckpoint(int touche){
  glPushMatrix();
    glPushMatrix();
 		if(touche) glColor3f(0.5,0.5,0.5);
 		else glColor3f(0.56,0.33,0);
      glScalef(4.5,1.,1.);
      dessinCarreBordRond(1);
    glPopMatrix();
    glColor3f(1,1,1);
    glBegin(GL_QUADS);
      glVertex2f(-2,-0.3);
      glVertex2f(-2,0.3);
      glVertex2f(-1,0.3);
      glVertex2f(-1,-0.3);
    glEnd();
    glColor3f(0.98,0.78,0.17);
    glBegin(GL_QUADS);
      glVertex2f(-1,-0.3);
      glVertex2f(-1,0.3);
      glVertex2f(1,0.3);
      glVertex2f(1,-0.3);
    glEnd();
    glColor3f(0.91,0.66,0);
    glBegin(GL_QUADS);
      glVertex2f(1,-0.3);
      glVertex2f(1,0.3);
      glVertex2f(2,0.3);
      glVertex2f(2,-0.3);
    glEnd();
  glPopMatrix();
}

void dessinPieceFace(){
  glPushMatrix();
    glPushMatrix();
      glColor3f(0.56,0.33,0);
      glScalef(42.,45.,1.);
      dessinCercle(1);
    glPopMatrix();
    glPushMatrix();
      glColor3f(1,0.83,0.17);
      glScalef(37.,40.,1.);
      dessinCercle(1);
    glPopMatrix();
    glPushMatrix();
      glColor3f(0.91,0.66,0);
      glScalef(26.,29.,1.);
      dessinCercle(1);
    glPopMatrix();
    glPushMatrix();
      glColor3f(0.98,0.78,0.17);
      glScalef(22.,25.,1.);
      dessinCercle(1);
    glPopMatrix();
    glPushMatrix();
      glColor3f(0.91,0.66,0);
      glTranslatef(-1,0,0);
      glScalef(5.,17.,1.);
      dessinCarre(1);
    glPopMatrix();
    glPushMatrix();
      glColor3f(1,1,1);
      glScalef(3.5,15.,1.);
      dessinCarre(1);
    glPopMatrix();
  glPopMatrix();
}




