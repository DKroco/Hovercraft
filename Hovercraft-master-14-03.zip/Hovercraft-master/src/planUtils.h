#ifndef PLANUTILS_H
#define PLANUTILS_H

typedef struct {
	int x;
	int y;
} Coordonnees;

typedef Coordonnees Vecteur;

const float PI = 3.14;
const int CONST_SEGM = 100;

Coordonnees * init_coordonnees(int x, int y);
Vecteur * init_vecteur(int x, int y);
void dessinCarre(int full);
void dessinCercle(int full);
void dessinCarreBordRond(int full);

#endif