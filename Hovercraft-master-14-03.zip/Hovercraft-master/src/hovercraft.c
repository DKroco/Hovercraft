#include <stdlib.h>
#include <stdio.h>

#include "hovercraft.h"
#include "terrain.h"
//#include "planUtils.h"




Hovercraft * init_hovercraft(Coordonnees *pos) {
	Hovercraft *hc = malloc(1*sizeof(Hovercraft));
	hc->pos = pos;
	hc->vitesse = init_vecteur(0, 0);
	hc->acceleration = init_vecteur(0, 0);
	return hc;
}



// void draw_hovercraft(Hovercraft *hv) {
//   glPushMatrix();
//     glTranslatef(hv->pos->x, hv->pos->y, 0);
//     dessinHovercraft();
//   glPopMatrix();
// }


void dessinHovercraft(){
  int i;

  // les boués

  glPushMatrix();
    glColor3f(0.4,0.4,0.45);
    glBegin(GL_QUADS);
      glVertex2f(-20,12);
      glVertex2f(-7,33);
      glVertex2f(7,33);
      glVertex2f(20,12);
    glEnd();
    glPushMatrix();
      glScalef(38.5,40.,1.);
      dessinCarreBordRond(1);
    glPopMatrix();
    glPushMatrix();
      glTranslatef(0,-18,0); 
      glScalef(38.5,40.,1.);
      dessinCarreBordRond(1);
    glPopMatrix();
  glPopMatrix();

  for(i =0; i < 6; i++){
    glPushMatrix();
      glColor3f(0.3,0.3,0.3);
      glTranslatef(0,-30+7*i,0); 
      glBegin(GL_POLYGON);
        glVertex2f(-20,i);
        glVertex2f(-20,i+1);
        glVertex2f(0,i-2);
        glVertex2f(20,i+1);
        glVertex2f(20,i);
        glVertex2f(0,i-3);
      glEnd();
    glPopMatrix();
  }

  // la partie bleue claire

  glPushMatrix();
    glColor3f(0.45,0.8,1);
    glBegin(GL_POLYGON);
      glVertex2f(-15,0);
      glVertex2f(-15,10);
      glVertex2f(-3,30);
      glVertex2f(3,30);
      glVertex2f(15,10);
      glVertex2f(15,0);
    glEnd();
    glPushMatrix();
      glTranslatef(0,-5,0);
      glScalef(30.,30.,1.);
      dessinCarreBordRond(1);
    glPopMatrix();
    glPushMatrix();
      glTranslatef(0,-20,0);
      glScalef(30.,30.,1.);
      dessinCarreBordRond(1);
    glPopMatrix();
  glPopMatrix();

  // l'intérieur

  glPushMatrix();
    glColor3f(0.1,0.3,0.5);
    glBegin(GL_POLYGON);
      glVertex2f(-3,20);
      glVertex2f(-11,10);
      glVertex2f(-11,-30);
      glVertex2f(11,-30);
      glVertex2f(11,10);
      glVertex2f(3,20);
      glVertex2f(3,30);
      glVertex2f(-3,30);
    glEnd();
    glColor3f(0.9,0.9,1);
    glBegin(GL_QUADS);
      glVertex2f(-8,5);
      glVertex2f(-8,-23);
      glVertex2f(8,-23);
      glVertex2f(8,5);
    glEnd();
    glColor3f(0.9,0.9,1);
    glBegin(GL_QUADS);
      glVertex2f(-8,5);
      glVertex2f(8,5);
      glVertex2f(1,15);
      glVertex2f(-1,15);
    glEnd();
    glColor3f(0.1,0.1,0.1);
    glBegin(GL_QUADS);
      glVertex2f(-6,5);
      glVertex2f(-6,-23);
      glVertex2f(6,-23);
      glVertex2f(6,5);
    glEnd();
  glPopMatrix();

  // Les ronds

  glPushMatrix();
    glPushMatrix();
      glColor3f(0.9,0.6,0.4);
      glTranslatef(0,-1.5,0);
      glScalef(8.,8.,1.);
      dessinCercle(1);
    glPopMatrix();
    glPushMatrix();
      glColor3f(0.3,0.3,0.4);
      glTranslatef(0,-35,0);
      glScalef(14.,9.,1.);
      dessinCercle(1);
    glPopMatrix();
    
    glPushMatrix();
     glColor3f(0.95,0.95,1);
      glTranslatef(0,-38,0);
      glScalef(12.,6.,1.);
      dessinCercle(1);
    glPopMatrix();
    
  glPopMatrix();

}


