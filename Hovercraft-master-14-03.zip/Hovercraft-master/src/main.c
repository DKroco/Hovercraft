#include <SDL/SDL.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
 
#include "planUtils.c"
#include "hovercraft.c" 
#include "terrain.c" 
   

/* Nombre de bits par pixel de la fenêtre */
static const unsigned int BIT_PER_PIXEL = 32;

/* Nombre minimal de millisecondes separant le rendu de deux images */
static const Uint32 FRAMERATE_MILLISECONDS = 1000 / 60;
    

void reshape(unsigned int windowWidth, unsigned int windowHeight) {
  glViewport(0, 0, windowWidth, windowHeight);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  gluOrtho2D(-200., 200., -200. * windowHeight/windowWidth, 200.*windowHeight/windowWidth);
}

  

void setVideoMode(unsigned int windowWidth, unsigned int windowHeight) {
  if(NULL == SDL_SetVideoMode(windowWidth, windowHeight, BIT_PER_PIXEL, SDL_OPENGL | SDL_RESIZABLE | SDL_GL_DOUBLEBUFFER)) {
    fprintf(stderr, "Impossible d'ouvrir la fenetre. Fin du programme.\n");
    exit(EXIT_FAILURE);
  }
}

int collisionHC(int hPosX, int hPosY, int cPosX, int cPosY, float rayon){
  if(hPosX-30 < cPosX+rayon && hPosX+30 > cPosX-rayon && hPosY-40 < cPosY+rayon && hPosY+40 > cPosY-rayon)
      return 1;
  else
    return 0;
  
}  



int main(int argc, char** argv) {

  Hovercraft *hv = init_hovercraft(init_coordonnees(0,0));
  Checkpoint *cp = init_checkpoint(init_coordonnees(-100,-100),10.);
  

  /* Dimensions de la fenêtre */
  unsigned int windowWidth  = 800;
  unsigned int windowHeight = 600;
  float alpha = 0, rotation = 1;
  int collision = 0;

  /* Initialisation de la SDL */
  if(-1 == SDL_Init(SDL_INIT_VIDEO)) {
    fprintf(stderr, "Impossible d'initialiser la SDL. Fin du programme.\n");
    return EXIT_FAILURE;
  }
  
  /* Ouverture d'une fenêtre et création d'un contexte OpenGL */
  setVideoMode(windowWidth, windowHeight);
  reshape(windowWidth, windowHeight);  

  /* Titre de la fenêtre */
  SDL_WM_SetCaption("Hovercraft", NULL);

  /*Listes */

  GLuint idHovercraft;
  idHovercraft = glGenLists(1);
  glNewList(idHovercraft,GL_COMPILE);
  dessinHovercraft();   
  glEndList();

  GLuint idCheckpoint;
  idCheckpoint = glGenLists(1);
  glNewList(idCheckpoint,GL_COMPILE);
  dessinCheckpoint(0);   
  glEndList();

  GLuint idCheckpointTouche;
  idCheckpointTouche = glGenLists(1);
  glNewList(idCheckpointTouche,GL_COMPILE);
  dessinCheckpoint(1);   
  glEndList();

  GLuint idPiece;
  idPiece = glGenLists(1);
  glNewList(idPiece,GL_COMPILE);
  dessinPieceFace();   
  glEndList(); 


  /* Boucle d'affichage */
  int loop = 1;
  int leftPressed = 0, rightPressed = 0, upPressed = 0, downPressed = 0;

  while(loop) {
    /* Récupération du temps au début de la boucle */
    Uint32 startTime = SDL_GetTicks();
    
    /* Placer ici le code de dessin */
    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    if (leftPressed)
      hv->pos->x += -1;
    if (rightPressed)
      hv->pos->x += 1;
    if (upPressed)
      hv->pos->y += 1;
    if (downPressed)
      hv->pos->y += -1;

    if(collision == 0)
      collision = collisionHC(hv->pos->x, hv->pos->y, cp->pos->x, cp->pos->y, cp->rayon);

    
    glPushMatrix();
      glTranslatef(cp->pos->x, cp->pos->y, 0);
      glRotatef(alpha,0.0,0.0,1.0);
      glScalef(cp->rayon,cp->rayon,1.);
      if(collision){
        glCallList(idCheckpointTouche);
      }else{
        glCallList(idCheckpoint);
      }
    glPopMatrix();
    
    
     glPushMatrix();
      glTranslatef(hv->pos->x, hv->pos->y, 0);
      glScalef(0.8,0.8,1.);
      glCallList(idHovercraft);
    glPopMatrix();

    
    
    alpha = alpha + rotation;

    glPushMatrix();
      glTranslatef(-100,100,0);
      glCallList(idPiece);
    glPopMatrix();







    
    // draw_hovercraft(hv);
    
    /* Echange du front et du back buffer : mise à jour de la fenêtre */
    SDL_GL_SwapBuffers();
    
    /* Boucle traitant les evenements */
    SDL_Event e;
    while(SDL_PollEvent(&e)) {
      /* L'utilisateur ferme la fenêtre : */
      if(e.type == SDL_QUIT) {
        loop = 0;
        break;
      }
      
      /* Quelques exemples de traitement d'evenements : */
      switch(e.type) {
        /* Clic souris */
        case SDL_MOUSEBUTTONUP:
         // printf("clic en (%d, %d)\n", e.button.x, e.button.y);
          break;

        /* move the mouse */           
        case SDL_MOUSEMOTION:
          
          break;

        /* Touche clavier */
        case SDL_KEYDOWN:
          //printf("touche pressée (code = %d)\n", e.key.keysym.sym);
          switch (e.key.keysym.sym) {
            case SDLK_a: //TODO Attention, a modifier! Sur windows, le clavier est considéré comme qwerty...
              loop = 0;
              break;
            case SDLK_LEFT:
              leftPressed = 1;
              break;
            case SDLK_RIGHT:
              rightPressed = 1;
              break;
            case SDLK_UP:
              upPressed = 1;
              break;
            case SDLK_DOWN:
              downPressed = 1;
              break;
            if(e.key.keysym.sym == SDLK_q)
              loop = 0;
              break;
            default:
              break;
          }
          break;

        case SDL_KEYUP:
          //printf("touche pressée (code = %d)\n", e.key.keysym.sym);
          switch (e.key.keysym.sym) {
            case SDLK_LEFT:
              leftPressed = 0;
              break;
            case SDLK_RIGHT:
              rightPressed = 0;
              break;
            case SDLK_UP:
              upPressed = 0;
              break;
            case SDLK_DOWN:
              downPressed = 0;
              break;
            default:
              break;
          }
          break;
          
        /* resize window */
        case SDL_VIDEORESIZE:
          windowWidth  = e.resize.w;
          windowHeight = e.resize.h;
          setVideoMode(windowWidth, windowHeight);
          reshape(windowWidth, windowHeight);
          break;
 
        default:
          break;
      }
    }

    /* Calcul du temps écoulé */
    Uint32 elapsedTime = SDL_GetTicks() - startTime;

    /* Si trop peu de temps s'est écoulé, on met en pause le programme */
    if(elapsedTime < FRAMERATE_MILLISECONDS) {
      SDL_Delay(FRAMERATE_MILLISECONDS - elapsedTime);
    }
  }
  
  /* Liberation des ressources associées à la SDL */ 
  SDL_Quit();
  
  return EXIT_SUCCESS;
}
