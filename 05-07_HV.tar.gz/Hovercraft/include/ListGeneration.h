#ifndef LISTGENERATION_H
#define LISTGENERATION_H

#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <GL/gl.h>
#include <GL/glu.h>

#include "Playground.h"
#include "DrawFunctions.h"

#define NB_PRINTLISTS 6
/* Permet de créer un tableau associatif pour les listes d'affichage */
typedef enum {
	ID_HOVERCRAFT,
	ID_HOVERCRAFT_J2,
	ID_PIECE,
	ID_PIECE_TOUCHE,
	ID_PIECE_J2_TOUCHE,
	ID_CHECKPOINT
} ID_PRINTLIST;

#define NB_TEXTURES 12

/* Permet de créer un tableau associatif pour les textures */
typedef enum {
	BACKGROUND_TEXTURE,
	MENU_SCREEN,
	ERROR_SCREEN,
	PAUSE_SCREEN,
	EASTER_EGG_SCREEN,
	TUTORIAL_SCREEN,
	LEVEL_SELECTION_SCREEN,
	SOLO_WIN_SCREEN,
	MULTI_WIN_P1_SCREEN,
	MULTI_WIN_P2_SCREEN,
	EQUAL_SCREEN,
	GAME_OVER_SCREEN
} ID_TEXTURE;

/* Permet la création de toutes les listes d'affichages utilisées */
GLuint * generatePrintLists();

void freePrintlists(GLuint **printlists);

GLenum getImgFormat(SDL_Surface *image);

/* Ouverture de l'image imgPath */
SDL_Surface * loadImage(char imgPath[]);

/* Permet de créer la texture engendrée par imgPath */
GLuint createTexture(char imgPath[]);

/* Permet la création de toutes les textures utilisées */
GLuint * generateTextures();

void freeTextures(GLuint **textures);

#endif