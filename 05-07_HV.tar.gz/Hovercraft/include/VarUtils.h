#ifndef VARUTILS_H
#define VARUTILS_H

/* Définir si on est sur un OS Linux ou Windows */
#ifdef __unix__
#elif defined(_WIN32) || defined(WIN32) 
  #define OS_Windows
#endif

#define PI 3.1415
#define MAX_SIZE 200 /* Taille maximale d'un buffer de texte */
#define MAX_FILENAME 45 /* Taille maximale du nom de level */

#endif