#ifndef DRAWSCREENFUNCTIONS_H
#define DRAWSCREENFUNCTIONS_H

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>

#include "Hovercraft.h"
#include "Playground.h"
#include "ListGeneration.h"

/* Le chronometre */
int timer(Uint32 *currentTime, Uint32 *beforeTime, int *seconds, float *widthTimer, float timerDownInterval);

/* Afficher une image de fond 
L'image est définie par le textureId et est affichée dans un écran de taille size */
void drawTexturedScreen(GLuint textureId, Size size);

/* Fonction de rotation de la boussole*/
void rotateCompass(float *arrowAlpha, Playground *playground, Hovercraft *hovercraft);

/* Dessin des interfaces */
void drawSoloInterface(Player *player, Playground *playground, Hovercraft *hovercraft, GLuint printlist[], float *arrowAlpha, float widthTimer, float widthTimerReset, float widthSquareReset);

void drawMultiInterface(Player *playerOne, Player *playerTwo, Playground *playground, GLuint printlist[], float *arrowAlphaOne, float *arrowAlphaTwo);

/* Affichage des écrans de jeu */
void drawSoloGame(float scale, float *alpha, float rotation, GLuint *printlists, Playground *playground, Hovercraft *hovercraft, GLuint backgroundTexture);

void drawMultiGame(float scale, float *alpha, float rotation, GLuint *printlists, Playground *playground, Hovercraft *hovercraftOne, Hovercraft *hovercraftTwo, GLuint backgroundTexture);

#endif